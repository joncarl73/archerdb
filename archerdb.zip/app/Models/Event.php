<?php

namespace App\Models;

use App\Enums\EventKind;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Event extends Model
{
    use HasFactory;

    // ---- Scoring modes (aligned with leagues)
    public const SCORING_PERSONAL = 'personal_device';

    public const SCORING_TABLET = 'tablet';

    // ---- Registration/payment type (aligned with leagues/products)
    public const TYPE_OPEN = 'open';

    public const TYPE_CLOSED = 'closed';

    protected $fillable = [
        'company_id',
        'public_uuid',
        'title',
        'location',
        'kind',              // EventKind backed enum
        'starts_on',
        'ends_on',
        'is_published',

        // Parity with leagues:
        'type',              // 'open' | 'closed'
        'scoring_mode',      // 'personal_device' | 'tablet'

        // Rules
        'ruleset_id',

        // Range (company-owned shooting layout template)
        'range_id',
    ];

    protected $casts = [
        'starts_on' => 'date',
        'ends_on' => 'date',
        'is_published' => 'bool',
        'kind' => EventKind::class, // backed enum cast (string)
    ];

    protected static function booted(): void
    {
        static::creating(function ($model) {
            if (! $model->public_uuid) {
                $model->public_uuid = (string) Str::uuid();
            }

            // Sensible defaults to mirror league creation UX
            $model->type ??= self::TYPE_OPEN;
            $model->scoring_mode ??= self::SCORING_PERSONAL;

            // NOTE: lanes are NOT event-owned. They are now Range-owned (preferred),
            // with Ruleset as a legacy fallback for older records.
        });

        static::saving(function ($model) {
            // Type
            if (! in_array($model->type, [self::TYPE_OPEN, self::TYPE_CLOSED], true)) {
                $model->type = self::TYPE_OPEN;
            }

            // Scoring mode
            if (! in_array($model->scoring_mode, [self::SCORING_PERSONAL, self::SCORING_TABLET], true)) {
                $model->scoring_mode = self::SCORING_PERSONAL;
            }

            // NOTE: do not normalize lane_* here.
            // range_id is optional; ruleset_id optional; both can coexist during transition.
        });
    }

    // ---------------- Relationships ----------------

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function ruleset()
    {
        return $this->belongsTo(Ruleset::class);
    }

    public function rulesetOverrides()
    {
        return $this->hasOne(EventRulesetOverride::class);
    }

    public function lineTimes()
    {
        return $this->hasMany(EventLineTime::class)
            ->orderBy('line_date')
            ->orderBy('start_time');
    }

    public function collaborators()
    {
        // Matches league_users style but for events
        return $this->belongsToMany(User::class, 'event_users')
            ->withPivot('role')
            ->withTimestamps();
    }

    public function owners()
    {
        return $this->collaborators()->wherePivot('role', 'owner');
    }

    public function managers()
    {
        return $this->collaborators()->wherePivot('role', 'manager');
    }

    public function range()
    {
        return $this->belongsTo(Range::class);
    }

    // ---------------- Convenience ----------------

    public function userRoleFor(User $user): ?string
    {
        return $this->collaborators()
            ->where('user_id', $user->id)
            ->first()?->pivot?->role;
    }

    public function belongsToSameCompany(User $user): bool
    {
        return (int) $this->company_id === (int) $user->company_id;
    }

    public function isSingleDay(): bool
    {
        return $this->kind === EventKind::SingleDay;
    }

    public function isOpen(): bool
    {
        return $this->type === self::TYPE_OPEN;
    }

    public function isClosed(): bool
    {
        return $this->type === self::TYPE_CLOSED;
    }

    /**
     * LEGACY (fallback) behavior:
     * Number of shooters per lane based on the linked ruleset's lane_breakdown.
     * Falls back to 1 if no ruleset or unknown value.
     *
     * Range-based layouts may have varying slots per lane, so this method is only used
     * when no range is selected (or range missing).
     */
    public function slotsPerLane(): int
    {
        $breakdown = $this->ruleset?->lane_breakdown ?: 'single';

        // Examples:
        // 'single' => 1
        // 'AB' => 2
        // 'ABCD' => 4
        return $breakdown === 'single' ? 1 : mb_strlen($breakdown);
    }

    /**
     * Returns the maximum number of slot labels on any lane in the selected range.
     * Useful for UI hints. If no range selected, returns legacy slotsPerLane().
     */
    public function maxSlotsPerLane(): int
    {
        $range = $this->relationLoaded('range') ? $this->range : null;

        if (! $range && $this->range_id) {
            $range = $this->range()->first();
        }

        if ($range) {
            // Expect lane_slot_groups = [ ["A","C"], ["B","D"] ]
            $groups = is_array($range->lane_slot_groups) ? $range->lane_slot_groups : [];
            $max = 1;

            foreach ($groups as $g) {
                if (is_array($g)) {
                    $max = max($max, count($g));
                }
            }

            return max(1, $max);
        }

        return $this->slotsPerLane();
    }

    /**
     * Range-first suggested capacity for a line time.
     *
     * - If a Range is selected, capacity = range.positionsCount()
     * - Else fallback to legacy ruleset-based capacity: lanes_count × slotsPerLane()
     *
     * Important: this is a suggestion/default; line times can still override capacity.
     */
    public function suggestedCapacity(): int
    {
        $range = $this->relationLoaded('range') ? $this->range : null;

        if (! $range && $this->range_id) {
            $range = $this->range()->first();
        }

        if ($range) {
            // If your Range model has a method positionsCount(), use it.
            // Otherwise compute it safely from stored config.
            if (method_exists($range, 'positionsCount')) {
                return max(1, (int) $range->positionsCount());
            }

            $groups = is_array($range->lane_slot_groups) ? $range->lane_slot_groups : [];
            $perBale = 0;

            foreach ($groups as $g) {
                $perBale += is_array($g) ? count($g) : 0;
            }

            $bales = (int) ($range->bales_count ?? 1);

            return max(1, $bales * max(1, $perBale));
        }

        // Legacy fallback (ruleset-owned lanes)
        $lanes = (int) ($this->ruleset?->lanes_count ?? 1);

        return max(1, $lanes * $this->slotsPerLane());
    }

    /**
     * Range-first lane options for CLS assignment (lane_number + slot label).
     * If no range selected, returns legacy options derived from ruleset lane_breakdown + lanes_count.
     *
     * Returns array like: ["1A","1C","2B","2D", ...]
     */
    public function laneOptions(): array
    {
        $range = $this->relationLoaded('range') ? $this->range : null;

        if (! $range && $this->range_id) {
            $range = $this->range()->first();
        }

        if ($range) {
            if (method_exists($range, 'laneOptions')) {
                return $range->laneOptions();
            }

            $bales = max(1, (int) ($range->bales_count ?? 1));
            $lanesPerBale = max(1, (int) ($range->lanes_per_bale ?? 1));

            $groups = is_array($range->lane_slot_groups) ? $range->lane_slot_groups : [];
            $fallback = [
                ['A', 'C'],
                ['B', 'D'],
            ];

            // Normalize groups length to lanes_per_bale
            if (count($groups) < $lanesPerBale) {
                $groups = array_pad($groups, $lanesPerBale, []);
            } elseif (count($groups) > $lanesPerBale) {
                $groups = array_slice($groups, 0, $lanesPerBale);
            }

            // If empty or malformed, use fallback
            $allEmpty = true;
            foreach ($groups as $g) {
                if (is_array($g) && count($g) > 0) {
                    $allEmpty = false;
                    break;
                }
            }
            if ($allEmpty) {
                $groups = $fallback;
            }

            $lanesCount = $bales * $lanesPerBale;
            $opts = [];

            for ($laneNumber = 1; $laneNumber <= $lanesCount; $laneNumber++) {
                $laneWithinBale = ($laneNumber - 1) % $lanesPerBale; // 0..lanesPerBale-1
                $slots = $groups[$laneWithinBale] ?? ['SINGLE'];

                foreach ($slots as $slot) {
                    $slot = strtoupper(trim((string) $slot));
                    if ($slot === '') {
                        continue;
                    }
                    $opts[] = (string) $laneNumber.$slot;
                }
            }

            return $opts ?: ['1SINGLE'];
        }

        // Legacy fallback
        $lanes = max(1, (int) ($this->ruleset?->lanes_count ?? 1));
        $breakdown = $this->ruleset?->lane_breakdown ?: 'single';

        $letters = match ($breakdown) {
            'ABCD' => ['A', 'B', 'C', 'D'],
            'AB' => ['A', 'B'],
            default => ['SINGLE'],
        };

        $opts = [];
        for ($i = 1; $i <= $lanes; $i++) {
            foreach ($letters as $s) {
                $opts[] = (string) $i.$s;
            }
        }

        return $opts;
    }

    // ---------------- Related data ----------------

    public function participants()
    {
        return $this->hasMany(\App\Models\EventParticipant::class);
    }

    public function participantImports()
    {
        return $this->hasMany(\App\Models\ParticipantImport::class);
    }

    public function checkins()
    {
        return $this->hasMany(\App\Models\EventCheckin::class);
    }

    public function scores()
    {
        return $this->hasMany(EventScore::class);
    }
}
