<?php

namespace App\Enums;

enum LeagueType: string
{
    case Open = 'open';
    case Closed = 'closed';
}
