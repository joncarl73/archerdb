<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\StripeServiceProvider::class,
    App\Providers\VoltServiceProvider::class,
];
