<x-layouts.auth.split>
    {{ $slot }}
</x-layouts.auth.split>
