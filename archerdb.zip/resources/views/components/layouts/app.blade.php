<x-layouts.app.sidebar>
    <flux:main container>
        {{ $slot }}
    </flux:main>
</x-layouts.app.sidebar>