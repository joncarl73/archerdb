<?php
use App\Models\BowType;
use App\Models\Discipline;
use App\Models\Division;
use App\Models\Ruleset;
use App\Models\RulesetClass;
use App\Models\TargetFace;
use App\Support\RulesetPresets;
use Illuminate\Support\Facades\Gate;
use Livewire\Volt\Component;

new class extends Component
{
    use \Livewire\WithPagination;

    // Table/pagination
    protected string $pageName = 'rulesetsPage';

    public string $search = '';

    public string $sort = 'name';

    public string $direction = 'asc';

    // Drawers
    public bool $showCreate = false;

    public bool $showEdit = false;

    // Lookups (collections)
    public $L_disciplines;

    public $L_bowTypes;

    public $L_targetFaces;

    public $L_divisions;

    public $L_classes;

    // Presets dropdown options (key => label)
    public array $presetOptions = [];

    // -----------------------
    // CREATE fields
    // -----------------------
    public string $c_preset_key = 'world_archery_target'; // default preset

    public ?string $c_org = null;

    public string $c_name = '';

    public ?string $c_description = null;

    public array $c_selected_disciplines = [];

    public array $c_selected_bow_types = [];

    public array $c_selected_target_faces = [];

    public array $c_selected_divisions = [];

    public array $c_selected_classes = [];

    public array $c_schema = []; // future detailed scoring JSON

    public string $c_scoring_csv = '1,2,3,4,5,6,7,8,9,10';

    public ?int $c_x_value = 10;

    public string $c_distances_csv = '18,50,60';

    // session & lanes
    public int $c_ends_per_session = 10;

    public int $c_arrows_per_end = 3;

    public string $c_lane_breakdown = 'single'; // single|AB|ABCD|ABCDEF

    public int $c_lanes_count = 10;

    // -----------------------
    // EDIT fields
    // -----------------------
    public ?int $editingId = null;

    public string $e_preset_key = 'custom'; // loaded from ruleset.preset_key (or custom)

    public ?string $e_org = null;

    public string $e_name = '';

    public ?string $e_description = null;

    public array $e_selected_disciplines = [];

    public array $e_selected_bow_types = [];

    public array $e_selected_target_faces = [];

    public array $e_selected_divisions = [];

    public array $e_selected_classes = [];

    public array $e_schema = [];

    public string $e_scoring_csv = '';

    public ?int $e_x_value = null;

    public string $e_distances_csv = '';

    public ?int $e_ends_per_session = null;

    public ?int $e_arrows_per_end = null;

    public string $e_lane_breakdown = 'single';

    public ?int $e_lanes_count = null;

    // -----------------------
    // Lifecycle
    // -----------------------
    public function mount(): void
    {
        $this->loadLookups();

        // Build presets dropdown options (key => label)
        $this->presetOptions = collect(RulesetPresets::all())
            ->mapWithKeys(fn ($p, $k) => [$k => $p['label']])
            ->toArray();
    }

    private function loadLookups(): void
    {
        // Preload lightweight display fields only
        $this->L_disciplines = Discipline::orderBy('label')->get(['id', 'key', 'label']);
        $this->L_bowTypes = BowType::orderBy('label')->get(['id', 'key', 'label']);
        $this->L_targetFaces = TargetFace::orderBy('label')->get(['id', 'key', 'label', 'kind', 'diameter_cm', 'zones']);
        $this->L_divisions = Division::orderBy('label')->get(['id', 'key', 'label']);
        $this->L_classes = RulesetClass::orderBy('label')->get(['id', 'key', 'label']);
    }

    public function with(): array
    {
        $q = Ruleset::query()
            ->where('company_id', auth()->user()->company_id)
            ->when($this->search !== '', function ($q) {
                $s = "%{$this->search}%";
                $q->where(fn ($w) => $w->where('name', 'like', $s)
                    ->orWhere('org', 'like', $s));
            })
            ->orderBy($this->sort, $this->direction);

        return ['rulesets' => $q->paginate(10, ['*'], $this->pageName)];
    }

    public function sortBy(string $col): void
    {
        if (! in_array($col, ['name', 'org'], true)) {
            return;
        }

        if ($this->sort === $col) {
            $this->direction = $this->direction === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sort = $col;
            $this->direction = 'asc';
        }
        $this->resetPage($this->pageName);
    }

    // -----------------------
    // Preset apply helpers
    // -----------------------
    private function applyPresetToCreate(string $key): void
    {
        $p = RulesetPresets::get($key);

        // Custom = user-managed fields; do not overwrite anything
        if (! $p || $key === 'custom') {
            return;
        }

        $this->c_org = $p['org'] ?? $this->c_org;

        if (! empty($p['scoring_csv'])) {
            $this->c_scoring_csv = $p['scoring_csv'];
        }

        if (! is_null($p['x_value'] ?? null)) {
            $this->c_x_value = (int) $p['x_value'];
        }

        if (! empty($p['distances_csv'])) {
            $this->c_distances_csv = $p['distances_csv'];
        }
    }

    private function applyPresetToEdit(string $key): void
    {
        $p = RulesetPresets::get($key);

        // Custom = user-managed fields; do not overwrite anything
        if (! $p || $key === 'custom') {
            return;
        }

        $this->e_org = $p['org'] ?? $this->e_org;

        if (! empty($p['scoring_csv'])) {
            $this->e_scoring_csv = $p['scoring_csv'];
        }

        if (! is_null($p['x_value'] ?? null)) {
            $this->e_x_value = (int) $p['x_value'];
        }

        if (! empty($p['distances_csv'])) {
            $this->e_distances_csv = $p['distances_csv'];
        }
    }

    public function updatedCPresetKey(): void
    {
        $this->resetErrorBag();
        $this->applyPresetToCreate($this->c_preset_key);
    }

    public function updatedEPresetKey(): void
    {
        $this->resetErrorBag();
        $this->applyPresetToEdit($this->e_preset_key);
    }

    // -----------------------
    // Helpers
    // -----------------------
    private function normalizeScoringCsv(?string $csv): array
    {
        if (! $csv) {
            return [];
        }

        $vals = array_filter(array_map('trim', explode(',', $csv)), fn ($v) => $v !== '');
        $ints = array_values(array_unique(array_map('intval', $vals)));
        sort($ints, SORT_NUMERIC);

        return $ints;
    }

    // Distances: accept "18,50,60" or "18m, 50M"; store as numeric meters
    private function normalizeDistancesCsv(?string $csv): array
    {
        if (! $csv) {
            return [];
        }

        $vals = array_filter(array_map('trim', explode(',', $csv)), fn ($v) => $v !== '');
        $nums = [];

        foreach ($vals as $v) {
            $v = preg_replace('/\s*m\s*$/i', '', $v);
            if ($v === '' || ! is_numeric($v)) {
                continue;
            }
            $nums[] = (int) round((float) $v);
        }

        $nums = array_values(array_unique($nums));
        sort($nums, SORT_NUMERIC);

        return $nums;
    }

    private function validateXAgainstScale(?int $x, array $scale, string $field): bool
    {
        if (is_null($x)) {
            return true;
        }

        if (empty($scale)) {
            $this->addError($field, 'Provide a scoring scale first.');

            return false;
        }

        $max = max($scale);

        if (! in_array($x, $scale, true) && $x !== $max + 1) {
            $this->addError($field, 'X value must be in the scale or exactly one more than the max (e.g., 11 for 1–10).');

            return false;
        }

        return true;
    }

    // -----------------------
    // Create drawer
    // -----------------------
    public function openCreate(): void
    {
        Gate::authorize('create', Ruleset::class);
        $this->resetErrorBag();

        // Reset all create-state fields
        $this->c_preset_key = 'world_archery_target';

        $this->c_org = null;
        $this->c_name = '';
        $this->c_description = null;

        $this->c_selected_disciplines = [];
        $this->c_selected_bow_types = [];
        $this->c_selected_target_faces = [];
        $this->c_selected_divisions = [];
        $this->c_selected_classes = [];

        $this->c_schema = [];
        $this->c_scoring_csv = '1,2,3,4,5,6,7,8,9,10';
        $this->c_x_value = 10;
        $this->c_distances_csv = '18,50,60';

        // Apply defaults for the chosen preset (so dropdown + fields match)
        $this->applyPresetToCreate($this->c_preset_key);

        $this->c_ends_per_session = 10;
        $this->c_arrows_per_end = 3;
        $this->c_lane_breakdown = 'single';
        $this->c_lanes_count = 10;

        $this->showCreate = true;
    }

    public function create(): void
    {
        Gate::authorize('create', Ruleset::class);

        $this->validate([
            'c_name' => ['required', 'string', 'max:255'],
            'c_scoring_csv' => ['required', 'string'],
            'c_x_value' => ['nullable', 'integer', 'min:0', 'max:100'],
            'c_distances_csv' => ['required', 'string'],

            'c_ends_per_session' => ['required', 'integer', 'min:1', 'max:1000'],
            'c_arrows_per_end' => ['required', 'integer', 'min:1', 'max:12'],
            'c_lane_breakdown' => ['required', 'in:single,AB,ABCD,ABCDEF'],
            'c_lanes_count' => ['required', 'integer', 'min:1', 'max:1000'],
        ], [], [
            'c_name' => 'name',
            'c_scoring_csv' => 'scoring scale',
            'c_x_value' => 'X value',
            'c_distances_csv' => 'distances',
            'c_ends_per_session' => 'ends per session',
            'c_arrows_per_end' => 'arrows per end',
            'c_lane_breakdown' => 'lane breakdown',
            'c_lanes_count' => 'lanes count',
        ]);

        $scale = $this->normalizeScoringCsv($this->c_scoring_csv);

        if (empty($scale)) {
            $this->addError('c_scoring_csv', 'Enter a comma-separated list of integers.');

            return;
        }

        if (! $this->validateXAgainstScale($this->c_x_value, $scale, 'c_x_value')) {
            return;
        }

        $distances = $this->normalizeDistancesCsv($this->c_distances_csv);

        if (empty($distances)) {
            $this->addError('c_distances_csv', 'Enter one or more distances in meters (e.g., 18,50,60).');

            return;
        }

        $r = Ruleset::create([
            'company_id' => auth()->user()->company_id,

            // NOTE: requires rulesets.preset_key + fillable('preset_key')
            'preset_key' => $this->c_preset_key === 'custom' ? null : $this->c_preset_key,

            'org' => $this->c_org,
            'name' => $this->c_name,
            'description' => $this->c_description,
            'schema' => $this->c_schema,
            'scoring_values' => $scale,
            'x_value' => $this->c_x_value,
            'distances_m' => $distances,
            'ends_per_session' => $this->c_ends_per_session,
            'arrows_per_end' => $this->c_arrows_per_end,
            'lane_breakdown' => $this->c_lane_breakdown,
            'lane_count' => $this->c_lanes_count,
        ]);

        // sync lookups (unchanged)
        $r->disciplines()->sync($this->c_selected_disciplines);
        $r->bowTypes()->sync($this->c_selected_bow_types);
        $r->targetFaces()->sync($this->c_selected_target_faces);
        $r->divisions()->sync($this->c_selected_divisions);
        $r->classes()->sync($this->c_selected_classes);

        $this->showCreate = false;
        session()->flash('ok', 'Ruleset created.');
        $this->resetPage($this->pageName);
    }

    // -----------------------
    // Edit drawer
    // -----------------------
    public function openEdit(int $id): void
    {
        $this->resetErrorBag();

        $r = Ruleset::query()
            ->where('company_id', auth()->user()->company_id)
            ->findOrFail($id);

        Gate::authorize('update', $r);

        $this->editingId = $r->id;

        // NOTE: requires rulesets.preset_key column; if absent, this will always be custom
        $this->e_preset_key = $r->preset_key ?? 'custom';

        $this->e_org = $r->org;
        $this->e_name = $r->name;
        $this->e_description = $r->description;

        // hydrate selections
        $this->e_schema = $r->schema ?? [];
        $this->e_selected_disciplines = $r->disciplines()->pluck('id')->toArray();
        $this->e_selected_bow_types = $r->bowTypes()->pluck('id')->toArray();
        $this->e_selected_target_faces = $r->targetFaces()->pluck('id')->toArray();
        $this->e_selected_divisions = $r->divisions()->pluck('id')->toArray();
        $this->e_selected_classes = $r->classes()->pluck('id')->toArray();

        $this->e_scoring_csv = implode(',', array_map('intval', $r->scoring_values ?? []));
        $this->e_x_value = $r->x_value;
        $this->e_distances_csv = implode(',', array_map('intval', $r->distances_m ?? []));

        $this->e_ends_per_session = $r->ends_per_session ?? 10;
        $this->e_arrows_per_end = $r->arrows_per_end ?? 3;
        $this->e_lane_breakdown = $r->lane_breakdown ?? 'single';
        $this->e_lanes_count = $r->lane_count ?? 10;

        $this->showEdit = true;
    }

    public function saveEdit(): void
    {
        if (! $this->editingId) {
            return;
        }

        $r = Ruleset::query()
            ->where('company_id', auth()->user()->company_id)
            ->findOrFail($this->editingId);

        Gate::authorize('update', $r);

        $this->validate([
            'e_name' => ['required', 'string', 'max:255'],
            'e_scoring_csv' => ['required', 'string'],
            'e_x_value' => ['nullable', 'integer', 'min:0', 'max:100'],
            'e_distances_csv' => ['required', 'string'],

            'e_ends_per_session' => ['required', 'integer', 'min:1', 'max:1000'],
            'e_arrows_per_end' => ['required', 'integer', 'min:1', 'max:12'],
            'e_lane_breakdown' => ['required', 'in:single,AB,ABCD,ABCDEF'],
            'e_lanes_count' => ['required', 'integer', 'min:1', 'max:1000'],
        ], [], [
            'e_name' => 'name',
            'e_scoring_csv' => 'scoring scale',
            'e_x_value' => 'X value',
            'e_distances_csv' => 'distances',
            'e_ends_per_session' => 'ends per session',
            'e_arrows_per_end' => 'arrows per end',
            'e_lane_breakdown' => 'lane breakdown',
            'e_lanes_count' => 'lanes count',
        ]);

        $scale = $this->normalizeScoringCsv($this->e_scoring_csv);

        if (empty($scale)) {
            $this->addError('e_scoring_csv', 'Enter a comma-separated list of integers.');

            return;
        }

        if (! $this->validateXAgainstScale($this->e_x_value, $scale, 'e_x_value')) {
            return;
        }

        $distances = $this->normalizeDistancesCsv($this->e_distances_csv);

        if (empty($distances)) {
            $this->addError('e_distances_csv', 'Enter one or more distances in meters (e.g., 18,50,60).');

            return;
        }

        $r->update([
            // NOTE: requires rulesets.preset_key + fillable('preset_key')
            'preset_key' => $this->e_preset_key === 'custom' ? null : $this->e_preset_key,

            'org' => $this->e_org,
            'name' => $this->e_name,
            'description' => $this->e_description,
            'schema' => $this->e_schema,
            'scoring_values' => $scale,
            'x_value' => $this->e_x_value,
            'distances_m' => $distances,
            'ends_per_session' => $this->e_ends_per_session,
            'arrows_per_end' => $this->e_arrows_per_end,
            'lane_breakdown' => $this->e_lane_breakdown,
            'lane_count' => $this->e_lanes_count,
        ]);

        // sync lookups (unchanged)
        $r->disciplines()->sync($this->e_selected_disciplines);
        $r->bowTypes()->sync($this->e_selected_bow_types);
        $r->targetFaces()->sync($this->e_selected_target_faces);
        $r->divisions()->sync($this->e_selected_divisions);
        $r->classes()->sync($this->e_selected_classes);

        $this->showEdit = false;
        session()->flash('ok', 'Ruleset updated.');
    }

    public function delete(int $id): void
    {
        $r = Ruleset::query()
            ->where('company_id', auth()->user()->company_id)
            ->findOrFail($id);

        Gate::authorize('delete', $r);

        $r->delete();
        session()->flash('ok', 'Ruleset deleted.');
        $this->resetPage($this->pageName);
    }
};
?>

<div class="mx-auto max-w-7xl relative">
  {{-- Header --}}
  <div class="sm:flex sm:items-center">
    <div class="sm:flex-auto">
      <h1 class="text-base font-semibold text-gray-900 dark:text-white">Rulesets</h1>
      <p class="mt-2 text-sm text-gray-700 dark:text-gray-300">
        Define disciplines, bow types, target faces, divisions, classes, scoring, distances, and session/lane settings for your company.
      </p>
    </div>
    <div class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
      <flux:button variant="primary" color="indigo" icon="plus" wire:click="openCreate">New ruleset</flux:button>
    </div>
  </div>

  {{-- Flash OK --}}
  @if (session('ok'))
    <div class="mt-4 rounded-md bg-emerald-50 p-3 text-sm text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300">
      {{ session('ok') }}
    </div>
  @endif

  {{-- Search --}}
  <div class="mt-4 max-w-sm">
    <flux:input icon="magnifying-glass" placeholder="Search name or org…" wire:model.live.debounce.250ms="search" />
  </div>

  {{-- Table --}}
  <div class="mt-6 overflow-hidden rounded-xl border border-gray-200 shadow-sm dark:border-zinc-700">
    <table class="w-full text-left">
      <thead class="bg-white dark:bg-gray-900">
        <tr>
          <th class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold">
            <button wire:click="sortBy('name')" class="flex items-center gap-1">
              Name @if($sort==='name')<span class="text-xs opacity-70">{{ $direction==='asc'?'▲':'▼' }}</span>@endif
            </button>
          </th>
          <th class="hidden md:table-cell px-3 py-3.5 text-sm font-semibold">
            <button wire:click="sortBy('org')" class="flex items-center gap-1">
              Org @if($sort==='org')<span class="text-xs opacity-70">{{ $direction==='asc'?'▲':'▼' }}</span>@endif
            </button>
          </th>
          <th class="hidden xl:table-cell px-3 py-3.5 text-sm font-semibold">Session</th>
          <th class="hidden xl:table-cell px-3 py-3.5 text-sm font-semibold">Lanes</th>
          <th class="hidden lg:table-cell px-3 py-3.5 text-sm font-semibold">Scoring</th>
          <th class="hidden lg:table-cell px-3 py-3.5 text-sm font-semibold">Distances</th>
          <th class="py-3.5 pl-3 pr-4 text-right text-sm font-semibold">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-100 dark:divide-white/10">
        @foreach ($rulesets as $r)
          <tr>
            <td class="py-3.5 pl-4 pr-3 text-sm font-medium">{{ $r->name }}</td>
            <td class="hidden md:table-cell px-3 py-3.5 text-sm text-gray-600 dark:text-gray-300">{{ $r->org ?: '—' }}</td>

            {{-- Session (ends × arrows, breakdown) --}}
            <td class="hidden xl:table-cell px-3 py-3.5 text-sm text-gray-600 dark:text-gray-300">
              @php
                $lane = $r->lane_breakdown ?? 'single';
                $ends = (int)($r->ends_per_session ?? 0);
                $arr  = (int)($r->arrows_per_end ?? 0);
                $slots = match($lane){ 'AB'=>2,'ABCD'=>4,'ABCDEF'=>6, default=>1 };
              @endphp
              @if($ends && $arr)
                {{ $ends }}×{{ $arr }} <span class="text-gray-400">·</span> {{ strtoupper($lane) }} ({{ $slots }}/lane)
              @else
                —
              @endif
            </td>

            {{-- Lanes count --}}
            <td class="hidden xl:table-cell px-3 py-3.5 text-sm text-gray-600 dark:text-gray-300">
              {{ (int)($r->lane_count ?? 0) ?: '—' }}
            </td>

            {{-- Scoring --}}
            <td class="hidden lg:table-cell px-3 py-3.5 text-sm text-gray-600 dark:text-gray-300">
              @php
                $vals = is_array($r->scoring_values ?? null) ? $r->scoring_values : [];
                $preview = empty($vals) ? '—' : (count($vals) > 6 ? (implode(',', array_slice($vals, 0, 6)).',…') : implode(',', $vals));
              @endphp
              <span class="whitespace-nowrap">{{ $preview }}</span>
              @if(!is_null($r->x_value))
                <span class="text-gray-400"> · X={{ $r->x_value }}</span>
              @endif
            </td>

            {{-- Distances --}}
            <td class="hidden lg:table-cell px-3 py-3.5 text-sm text-gray-600 dark:text-gray-300">
              @php
                $d = is_array($r->distances_m ?? null) ? $r->distances_m : [];
                $dPreview = empty($d) ? '—' : (count($d) > 4 ? (implode(',', array_slice($d, 0, 4)).',…') : implode(',', $d));
              @endphp
              <span class="whitespace-nowrap">{{ $dPreview }}</span><span class="text-gray-400">{{ empty($d) ? '' : ' m' }}</span>
            </td>

            <td class="py-3.5 pl-3 pr-4 text-right text-sm">
              <div class="inline-flex items-center gap-2">
                <flux:button size="sm" appearance="secondary" icon="pencil-square" wire:click="openEdit({{ $r->id }})">Edit</flux:button>
                <flux:button size="sm" appearance="danger" icon="trash" wire:click="delete({{ $r->id }})" onclick="return confirm('Delete this ruleset?');">Delete</flux:button>
              </div>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>

  {{-- Pagination --}}
  <div class="mt-4">
    {{ $rulesets->links() }}
  </div>

  {{-- CREATE DRAWER --}}
  @if($showCreate)
    <div class="fixed inset-0 z-40 bg-black/40" wire:click="$set('showCreate', false)" aria-hidden="true"></div>
    <aside class="fixed inset-y-0 right-0 z-50 w/full max-w-3xl bg-white dark:bg-zinc-900 shadow-xl border-l border-gray-200 dark:border-zinc-800 flex flex-col">
      <div class="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-zinc-800">
        <flux:text as="h2" class="text-lg font-semibold">New ruleset</flux:text>
        <flux:button icon="x-mark" appearance="ghost" size="sm" wire:click="$set('showCreate', false)" />
      </div>

      <div class="flex-1 overflow-auto p-5 space-y-6">
        {{-- Meta --}}
        <div class="grid gap-4 md:grid-cols-3">
          <div>
            <flux:label>Org (optional)</flux:label>
            <flux:input wire:model.defer="c_org" />
          </div>

          <div>
            <flux:label>Default scoring type</flux:label>
            <flux:select wire:model.live="c_preset_key">
              @foreach($presetOptions as $k => $label)
                <option value="{{ $k }}">{{ $label }}</option>
              @endforeach
            </flux:select>
            <flux:text class="text-xs text-gray-500">Selecting a preset can auto-fill scoring, X, and distances.</flux:text>
          </div>

          <div>
            <flux:label>Name</flux:label>
            <flux:input wire:model.defer="c_name" />
            @error('c_name')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>

          <div class="md:col-span-3">
            <flux:label>Description (optional)</flux:label>
            <flux:textarea rows="2" wire:model.defer="c_description" />
          </div>
        </div>

        {{-- Scoring + Distances --}}
        <div class="grid gap-4 md:grid-cols-3">
          <div class="md:col-span-2">
            <flux:label>Scoring scale (CSV)</flux:label>
            <flux:input wire:model.defer="c_scoring_csv" placeholder="e.g., 1,2,3,4,5,6,7,8,9,10" />
            @error('c_scoring_csv')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
            <flux:text class="text-xs text-gray-500">We’ll normalize this and store as an array.</flux:text>
          </div>
          <div>
            <flux:label>X value (optional)</flux:label>
            <flux:input type="number" min="0" max="100" wire:model.defer="c_x_value" placeholder="e.g., 10 or 11" />
            @error('c_x_value')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
          <div class="md:col-span-3">
            <flux:label>Distances (m, CSV)</flux:label>
            <flux:input wire:model.defer="c_distances_csv" placeholder="e.g., 18,50,60" />
            @error('c_distances_csv')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
        </div>

        {{-- Session & lanes --}}
        <div class="grid gap-4 md:grid-cols-4">
          <div>
            <flux:label>Ends per session</flux:label>
            <flux:input type="number" min="1" wire:model.defer="c_ends_per_session" />
            @error('c_ends_per_session')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
          <div>
            <flux:label>Arrows per end</flux:label>
            <flux:input type="number" min="1" max="12" wire:model.defer="c_arrows_per_end" />
            @error('c_arrows_per_end')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
          <div class="md:col-span-2 grid grid-cols-2 gap-4">
            <div>
              <flux:label>Lane breakdown</flux:label>
              <flux:select wire:model.defer="c_lane_breakdown">
                <option value="single">Single (1 per lane)</option>
                <option value="AB">A/B (2 per lane)</option>
                <option value="ABCD">A/B/C/D (4 per lane)</option>
                <option value="ABCDEF">A/B/C/D/E/F (6 per lane)</option>
              </flux:select>
              @error('c_lane_breakdown')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
            </div>
            <div>
              <flux:label>Lanes count</flux:label>
              <flux:input type="number" min="1" wire:model.defer="c_lanes_count" />
              @error('c_lanes_count')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
            </div>
          </div>
        </div>

        {{-- LOOKUPS — now in tabs (CREATE) --}}
        {{-- Accessible, simple Alpine tabs. No Livewire state changed, only layout. --}}
        <div x-data="{ tab: 'disciplines' }" class="mt-2">
          {{-- Tab list --}}
          <div role="tablist" aria-label="Ruleset lookups" class="flex flex-wrap gap-2 border-b border-gray-200 dark:border-zinc-800 pb-2">
            @php
              $tabs = [
                'disciplines' => 'Disciplines',
                'bowtypes'    => 'Bow types',
                'faces'       => 'Target faces',
                'divisions'   => 'Divisions',
                'classes'     => 'Classes',
            ]; @endphp

            @foreach($tabs as $value => $label)
              <button
                type="button"
                :aria-selected="tab==='{{ $value }}'"
                :class="tab==='{{ $value }}' ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900' : 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200'"
                @click="tab='{{ $value }}'"
                class="px-3 py-1.5 rounded-lg text-sm font-medium transition"
                role="tab"
              >{{ $label }}</button>
            @endforeach
          </div>

          {{-- Panels --}}
          <div class="mt-4">
            {{-- Disciplines --}}
            <div x-show="tab==='disciplines'" x-cloak role="tabpanel">
              <flux:label>Disciplines</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_disciplines as $d)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="c_selected_disciplines" value="{{ $d->id }}" />
                    <span>{{ $d->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Bow types --}}
            <div x-show="tab==='bowtypes'" x-cloak role="tabpanel">
              <flux:label>Bow types</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_bowTypes as $b)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="c_selected_bow_types" value="{{ $b->id }}" />
                    <span>{{ $b->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Target faces --}}
            <div x-show="tab==='faces'" x-cloak role="tabpanel">
              <flux:label>Target faces</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_targetFaces as $f)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="c_selected_target_faces" value="{{ $f->id }}" />
                    <span>{{ $f->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Divisions --}}
            <div x-show="tab==='divisions'" x-cloak role="tabpanel">
              <flux:label>Divisions</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_divisions as $v)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="c_selected_divisions" value="{{ $v->id }}" />
                    <span>{{ $v->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Classes --}}
            <div x-show="tab==='classes'" x-cloak role="tabpanel">
              <flux:label>Classes</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_classes as $c)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="c_selected_classes" value="{{ $c->id }}" />
                    <span>{{ $c->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>
          </div>
        </div>
        {{-- /LOOKUPS (CREATE) --}}
      </div>

      <div class="border-t border-gray-200 dark:border-zinc-800 px-5 py-4 flex items-center gap-2">
        <div class="ml-auto flex items-center gap-2">
          <flux:button size="sm" appearance="secondary" wire:click="$set('showCreate', false)">Cancel</flux:button>
          <flux:button size="sm" icon="check" wire:click="create">Save</flux:button>
        </div>
      </div>
    </aside>
  @endif

  {{-- EDIT DRAWER --}}
  @if($showEdit)
    <div class="fixed inset-0 z-40 bg-black/40" wire:click="$set('showEdit', false)" aria-hidden="true"></div>
    <aside class="fixed inset-y-0 right-0 z-50 w/full max-w-3xl bg-white dark:bg-zinc-900 shadow-xl border-l border-gray-200 dark:border-zinc-800 flex flex-col">
      <div class="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-zinc-800">
        <flux:text as="h2" class="text-lg font-semibold">Edit ruleset</flux:text>
        <flux:button icon="x-mark" appearance="ghost" size="sm" wire:click="$set('showEdit', false)" />
      </div>

      <div class="flex-1 overflow-auto p-5 space-y-6">
        {{-- Meta --}}
        <div class="grid gap-4 md:grid-cols-3">
          <div>
            <flux:label>Org (optional)</flux:label>
            <flux:input wire:model.defer="e_org" />
          </div>

          <div>
            <flux:label>Default scoring type</flux:label>
            <flux:select wire:model.live="e_preset_key">
              @foreach($presetOptions as $k => $label)
                <option value="{{ $k }}">{{ $label }}</option>
              @endforeach
            </flux:select>
            <flux:text class="text-xs text-gray-500">Selecting a preset can auto-fill scoring, X, and distances.</flux:text>
          </div>

          <div>
            <flux:label>Name</flux:label>
            <flux:input wire:model.defer="e_name" />
            @error('e_name')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>

          <div class="md:col-span-3">
            <flux:label>Description (optional)</flux:label>
            <flux:textarea rows="2" wire:model.defer="e_description" />
          </div>
        </div>

        {{-- Scoring + Distances --}}
        <div class="grid gap-4 md:grid-cols-3">
          <div class="md:col-span-2">
            <flux:label>Scoring scale (CSV)</flux:label>
            <flux:input wire:model.defer="e_scoring_csv" placeholder="e.g., 1,2,3,4,5,6,7,8,9,10" />
            @error('e_scoring_csv')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
            <flux:text class="text-xs text-gray-500">Stored as an array (JSON) on the ruleset.</flux:text>
          </div>
          <div>
            <flux:label>X value (optional)</flux:label>
            <flux:input type="number" min="0" max="100" wire:model.defer="e_x_value" placeholder="e.g., 10 or 11" />
            @error('e_x_value')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
          <div class="md:col-span-3">
            <flux:label>Distances (m, CSV)</flux:label>
            <flux:input wire:model.defer="e_distances_csv" placeholder="e.g., 18,50,60" />
            @error('e_distances_csv')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
        </div>

        {{-- Session & lanes --}}
        <div class="grid gap-4 md:grid-cols-4">
          <div>
            <flux:label>Ends per session</flux:label>
            <flux:input type="number" min="1" wire:model.defer="e_ends_per_session" />
            @error('e_ends_per_session')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
          <div>
            <flux:label>Arrows per end</flux:label>
            <flux:input type="number" min="1" max="12" wire:model.defer="e_arrows_per_end" />
            @error('e_arrows_per_end')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
          </div>
          <div class="md:col-span-2 grid grid-cols-2 gap-4">
            <div>
              <flux:label>Lane breakdown</flux:label>
              <flux:select wire:model.defer="e_lane_breakdown">
                <option value="single">Single (1 per lane)</option>
                <option value="AB">A/B (2 per lane)</option>
                <option value="ABCD">A/B/C/D (4 per lane)</option>
                <option value="ABCDEF">A/B/C/D/E/F (6 per lane)</option>
              </flux:select>
              @error('e_lane_breakdown')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
            </div>
            <div>
              <flux:label>Lanes count</flux:label>
              <flux:input type="number" min="1" wire:model.defer="e_lanes_count" />
              @error('e_lanes_count')<flux:text class="text-red-500 text-sm">{{ $message }}</flux:text>@enderror
            </div>
          </div>
        </div>

        {{-- LOOKUPS — now in tabs (EDIT) --}}
        <div x-data="{ tab: 'disciplines' }" class="mt-2">
          {{-- Tab list --}}
          <div role="tablist" aria-label="Ruleset lookups" class="flex flex-wrap gap-2 border-b border-gray-200 dark:border-zinc-800 pb-2">
            @php
              $tabs = [
                'disciplines' => 'Disciplines',
                'bowtypes'    => 'Bow types',
                'faces'       => 'Target faces',
                'divisions'   => 'Divisions',
                'classes'     => 'Classes',
            ]; @endphp

            @foreach($tabs as $value => $label)
              <button
                type="button"
                :aria-selected="tab==='{{ $value }}'"
                :class="tab==='{{ $value }}' ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900' : 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200'"
                @click="tab='{{ $value }}'"
                class="px-3 py-1.5 rounded-lg text-sm font-medium transition"
                role="tab"
              >{{ $label }}</button>
            @endforeach
          </div>

          {{-- Panels --}}
          <div class="mt-4">
            {{-- Disciplines --}}
            <div x-show="tab==='disciplines'" x-cloak role="tabpanel">
              <flux:label>Disciplines</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_disciplines as $d)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="e_selected_disciplines" value="{{ $d->id }}" />
                    <span>{{ $d->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Bow types --}}
            <div x-show="tab==='bowtypes'" x-cloak role="tabpanel">
              <flux:label>Bow types</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_bowTypes as $b)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="e_selected_bow_types" value="{{ $b->id }}" />
                    <span>{{ $b->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Target faces --}}
            <div x-show="tab==='faces'" x-cloak role="tabpanel">
              <flux:label>Target faces</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_targetFaces as $f)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="e_selected_target_faces" value="{{ $f->id }}" />
                    <span>{{ $f->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Divisions --}}
            <div x-show="tab==='divisions'" x-cloak role="tabpanel">
              <flux:label>Divisions</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_divisions as $v)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="e_selected_divisions" value="{{ $v->id }}" />
                    <span>{{ $v->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>

            {{-- Classes --}}
            <div x-show="tab==='classes'" x-cloak role="tabpanel">
              <flux:label>Classes</flux:label>
              <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                @foreach($L_classes as $c)
                  <label class="inline-flex items-center gap-2">
                    <flux:checkbox wire:model="e_selected_classes" value="{{ $c->id }}" />
                    <span>{{ $c->label }}</span>
                  </label>
                @endforeach
              </div>
            </div>
          </div>
        </div>
        {{-- /LOOKUPS (EDIT) --}}
      </div>

      <div class="border-t border-gray-200 dark:border-zinc-800 px-5 py-4 flex items-center gap-2">
        <flux:button size="sm" appearance="danger" icon="trash"
          wire:click="delete({{ $editingId ?? 0 }})"
          onclick="return confirm('Delete this ruleset?');">Delete</flux:button>
        <div class="ml-auto flex items-center gap-2">
          <flux:button size="sm" appearance="secondary" wire:click="$set('showEdit', false)">Cancel</flux:button>
          <flux:button size="sm" icon="check" wire:click="saveEdit">Save</flux:button>
        </div>
      </div>
    </aside>
  @endif
</div>
