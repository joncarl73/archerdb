<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <h1 class="text-xl font-semibold">Company Members — <?php echo e($company->company_name ?? 'Company'); ?></h1>
    </div>

    <?php if($errors->any()): ?> <div class="text-red-500"><?php echo e($errors->first()); ?></div> <?php endif; ?>
    <?php if(session('success')): ?> <div class="text-green-600"><?php echo e(session('success')); ?></div> <?php endif; ?>

    <form method="POST" action="<?php echo e(route('corporate.companies.members.store', $company)); ?>" class="flex gap-2">
      <?php echo csrf_field(); ?>
      <input name="email" type="email" placeholder="user@example.com" class="input input-bordered w-80">
      <button class="btn btn-primary">Add to company</button>
    </form>

    <div class="overflow-x-auto">
      <table class="table">
        <thead><tr><th>User</th><th>Email</th><th class="text-right">Actions</th></tr></thead>
        <tbody>
          <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($m->name); ?></td>
              <td><?php echo e($m->email); ?></td>
              <td class="text-right">
                <?php if($m->id !== $company->owner_user_id): ?>
                  <form method="POST" action="<?php echo e(route('corporate.companies.members.destroy', [$company,$m])); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-outline btn-sm">Remove</button>
                  </form>
                <?php else: ?>
                  <span class="opacity-60 text-sm">Owner</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/corporate/company/members.blade.php ENDPATH**/ ?>