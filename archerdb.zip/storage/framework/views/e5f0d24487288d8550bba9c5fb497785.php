<header class="sticky top-0 z-40 bg-white/80 backdrop-blur border-b border-neutral-200 dark:bg-neutral-950/80 dark:border-neutral-800">
  <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
    
    
    <div class="flex items-center">
      <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2 font-semibold pr-8">
        <?php if (isset($component)) { $__componentOriginal87f224b29228128a49d30612ade21da8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87f224b29228128a49d30612ade21da8 = $attributes; } ?>
<?php $component = App\View\Components\ArcherdbLogo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('archerdb-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ArcherdbLogo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87f224b29228128a49d30612ade21da8)): ?>
<?php $attributes = $__attributesOriginal87f224b29228128a49d30612ade21da8; ?>
<?php unset($__attributesOriginal87f224b29228128a49d30612ade21da8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87f224b29228128a49d30612ade21da8)): ?>
<?php $component = $__componentOriginal87f224b29228128a49d30612ade21da8; ?>
<?php unset($__componentOriginal87f224b29228128a49d30612ade21da8); ?>
<?php endif; ?>
        <span>ArcherDB</span>
      </a>

      <nav class="hidden md:flex items-center gap-6 text-sm">
        <a href="#features" class="hover:opacity-80">Features</a>
        <a href="#partners" class="hover:opacity-80">Partners</a>
        <a href="#pricing" class="hover:opacity-80">Pricing</a>
        <a href="#events" class="hover:opacity-80">Upcoming Events</a>
      </nav>
    </div>


    
    <div class="flex items-center gap-3">
      
      <button
        id="themeToggle"
        type="button"
        onclick="window.__setTheme?.()"
        class="h-10 w-10 inline-flex items-center justify-center rounded-md inset-ring inset-ring-zinc-300 hover:bg-zinc-50
               dark:inset-ring-zinc-700 dark:hover:bg-zinc-800"
        aria-label="Toggle theme"
        title="Toggle theme"
      >
        
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
             fill="currentColor" class="size-5 dark:hidden">
          <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 1 0 9.79 9.79Z"/>
        </svg>
        
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
             fill="currentColor" class="size-5 hidden dark:inline">
          <path d="M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Zm0 4a1 1 0 0 1-1-1v-1a1 1 0 1 1 2 0v1a1 1 0 0 1-1 1Zm0-18a1 1 0 0 1-1-1V2a1 1 0 1 1 2 0v1a1 1 0 0 1-1 1Zm10 9a1 1 0 0 1-1-1h-1a1 1 0 1 1 0-2h1a1 1 0 1 1 2 0 1 1 0 0 1-1 1ZM4 12a1 1 0 0 1-1 1H2a1 1 0 1 1 0-2h1a1 1 0 0 1 1 1Zm13.66 7.66a1 1 0 0 1-1.41 0l-.71-.71a1 1 0 1 1 1.41-1.41l.71.71a1 1 0 0 1 0 1.41Zm-9.9-9.9a1 1 0 0 1-1.41 0l-.71-.71A1 1 0 1 1 6.76 8.63l.71.71a1 1 0 0 1 0 1.41Zm9.9-3.1a1 1 0 0 1 0-1.41l.71-.71A1 1 0 1 1 19.59 6l-.71.71a1 1 0 0 1-1.41 0ZM5.05 19.59a1 1 0 0 1 0-1.41l.71-.71a1 1 0 1 1 1.41 1.41l-.71.71a1 1 0 0 1-1.41 0Z"/>
        </svg>
      </button>

      <?php if(Route::has('login')): ?>
          <nav class="flex items-center justify-end gap-4">
              <?php if(auth()->guard()->check()): ?>
                  <a
                      href="<?php echo e(url('/dashboard')); ?>"
                      class="inline-block px-5 py-1.5 dark:text-[#EDEDEC] border-[#19140035] hover:border-[#1915014a] border text-[#1b1b18] dark:border-[#3E3E3A] dark:hover:border-[#62605b] rounded-sm text-sm leading-normal"
                  >
                      Dashboard
                  </a>
              <?php else: ?>
                  <a
                      href="<?php echo e(route('login')); ?>"
                      class="inline-block px-5 py-1.5 dark:text-[#EDEDEC] text-[#1b1b18] border border-transparent hover:border-[#19140035] dark:hover:border-[#3E3E3A] rounded-sm text-sm leading-normal"
                  >
                      Log in
                  </a>

                  <?php if(Route::has('register')): ?>
                      <a
                          href="<?php echo e(route('register')); ?>"
                          class="inline-block px-5 py-1.5 dark:text-[#EDEDEC] border-[#19140035] hover:border-[#1915014a] border text-[#1b1b18] dark:border-[#3E3E3A] dark:hover:border-[#62605b] rounded-sm text-sm leading-normal">
                          Register
                      </a>
                  <?php endif; ?>
              <?php endif; ?>
          </nav>
      <?php endif; ?>
    </div>
  </div>
</header>
<?php /**PATH /var/www/archerdb.cloud/public/resources/views/landing/partials/nav.blade.php ENDPATH**/ ?>