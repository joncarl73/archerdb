

<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('page'); ?>
  
  <p class="mt-2 text-sm text-neutral-600 dark:text-neutral-400">
    We usually reply within 1–2 business days.
  </p>

  <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing.contact-form', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1889573656-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.layouts.page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/archerdb.cloud/public/resources/views/landing/contact.blade.php ENDPATH**/ ?>