
<?php if (isset($component)) { $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.public','data' => ['league' => $league]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['league' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($league)]); ?>
  <section class="w-full py-8">
    <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">

      
      <div class="relative overflow-hidden rounded-2xl border border-zinc-200 bg-gradient-to-br from-indigo-500/10 via-emerald-500/10 to-sky-500/10 p-6 shadow-sm dark:border-white/10">
        <div class="flex items-start justify-between gap-4">
          <div>
            <h1 class="text-xl font-semibold text-zinc-900 dark:text-zinc-100">Thanks for participating!</h1>
            <p class="mt-1 text-sm text-zinc-700 dark:text-zinc-300">
              Week #<?php echo e($score->week?->week_number ?? '—'); ?> •
              <?php echo e($score->arrows_per_end); ?> arrows/end •
              max <?php echo e($maxPerArrow); ?> points/arrow •
              X = <?php echo e($score->x_value); ?>

            </p>
          </div>
          <div class="shrink-0">
            <?php if (isset($component)) { $__componentOriginal4cc377eda9b63b796b6668ee7832d023 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cc377eda9b63b796b6668ee7832d023 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::badge.index','data' => ['color' => 'indigo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'indigo']); ?>League: <?php echo e($league->title); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $attributes = $__attributesOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $component = $__componentOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__componentOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
          </div>
        </div>
      </div>

      
      <div class="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div class="rounded-xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
          <div class="text-sm text-zinc-500 dark:text-zinc-400">Total score</div>
          <div class="mt-1 text-2xl font-semibold text-zinc-900 dark:text-zinc-100 tabular-nums">
            <?php echo e($totalScore); ?>

          </div>
          <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">Max (entered): <?php echo e($maxPossibleEntered); ?></div>
        </div>

        <div class="rounded-xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
          <div class="text-sm text-zinc-500 dark:text-zinc-400">Average / arrow</div>
          <div class="mt-1 text-2xl font-semibold text-zinc-900 dark:text-zinc-100 tabular-nums">
            <?php echo e(number_format($avgPerArrow, 2)); ?>

          </div>
          <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">Across <?php echo e($arrowsEntered); ?> arrows</div>
        </div>

        <div class="rounded-xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
          <div class="text-sm text-zinc-500 dark:text-zinc-400">Ends completed</div>
          <div class="mt-1 text-2xl font-semibold text-zinc-900 dark:text-zinc-100 tabular-nums">
            <?php echo e($endsCompleted); ?> / <?php echo e($plannedEnds); ?>

          </div>
          <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400"><?php echo e($completionPct); ?>% complete</div>
        </div>

        <div class="rounded-xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
          <div class="text-sm text-zinc-500 dark:text-zinc-400">X count</div>
          <div class="mt-1 text-2xl font-semibold text-zinc-900 dark:text-zinc-100 tabular-nums">
            <?php echo e($xCount); ?>

          </div>
          <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">X rate: <?php echo e($xRate); ?>%</div>
        </div>

        <div class="rounded-xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
          <div class="text-sm text-zinc-500 dark:text-zinc-400">Config</div>
          <div class="mt-1 text-sm text-zinc-900 dark:text-zinc-100">
            <?php echo e($arrowsPerEnd); ?> arrows/end • max <?php echo e($maxPerArrow); ?> pts/arrow
          </div>
          <?php if(($score->x_value ?? 10) > $maxPerArrow): ?>
            <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">X = <?php echo e($score->x_value); ?></div>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $attributes = $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $component = $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/public/scoring/summary.blade.php ENDPATH**/ ?>