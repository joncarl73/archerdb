


<?php $__env->startSection('title', $league->info->title ?? $league->title); ?>

<?php
  $fmt = fn($d) => $d ? $d->format('Y-m-d') : null;
?>

<?php $__env->startSection('content'); ?>
  
  <?php if($bannerUrl): ?>
    <section class="relative overflow-hidden">
      <img src="<?php echo e($bannerUrl); ?>" alt="<?php echo e($league->title); ?> banner" class="h-64 w-full object-cover sm:h-80 md:h-96">
      <div class="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-white to-transparent
                  dark:from-neutral-950 dark:to-transparent"></div>
    </section>
  <?php endif; ?>

  <section class="py-10 sm:py-12">
    <div class="mx-auto w-full max-w-5xl px-4 sm:px-6 lg:px-8 space-y-6">

      
      <div class="rounded-2xl border border-neutral-200 bg-white p-5 dark:border-neutral-800 dark:bg-neutral-900">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 class="text-2xl font-bold text-neutral-900 dark:text-neutral-100">
              <?php echo e($league->info->title ?? $league->title); ?>

            </h1>
            <p class="mt-1 text-sm text-neutral-600 dark:text-neutral-400">
              <?php echo e($league->location ?: '—'); ?> •
              <?php echo e(ucfirst($league->type->value ?? $league->type)); ?> League •
              Starts <?php echo e(optional($league->start_date)->format('Y-m-d') ?: '—'); ?> •
              <?php echo e($league->length_weeks); ?> weeks
            </p>
          </div>

          
          <div class="mt-1 sm:mt-0 text-right">
            <?php if($window === 'during'): ?>
              <?php if($registrationUrl): ?>
                <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($registrationUrl).'','target' => '_blank','rel' => 'noopener','variant' => 'primary','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($registrationUrl).'','target' => '_blank','rel' => 'noopener','variant' => 'primary','size' => 'sm']); ?>
                  Register now
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                <?php if($start || $end): ?>
                  <div class="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                    <?php if($start): ?> Opens <?php echo e($fmt($start)); ?>. <?php endif; ?>
                    <?php if($end): ?> Closes <?php echo e($fmt($end)); ?>. <?php endif; ?>
                  </div>
                <?php endif; ?>
              <?php else: ?>
                <div class="rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800 ring-1 ring-inset ring-emerald-200
                            dark:bg-emerald-900/20 dark:text-emerald-200 dark:ring-emerald-900/40">
                  Registration is open. <?php if($end): ?> Closes <?php echo e($fmt($end)); ?>. <?php endif; ?>
                </div>
              <?php endif; ?>

            <?php elseif($window === 'before'): ?>
              <div class="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900 ring-1 ring-inset ring-amber-200
                          dark:bg-amber-900/20 dark:text-amber-200 dark:ring-amber-900/40">
                Registration opens <?php echo e($fmt($start)); ?>.
              </div>

            <?php elseif($window === 'after'): ?>
              <div class="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-900 ring-1 ring-inset ring-rose-200
                          dark:bg-rose-900/20 dark:text-rose-200 dark:ring-rose-900/40">
                Registration closed<?php echo e($end ? ' on '.$fmt($end) : ''); ?>.
              </div>

            <?php else: ?>
              <?php if($registrationUrl): ?>
                <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($registrationUrl).'','target' => '_blank','rel' => 'noopener','variant' => 'primary','size' => 'md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($registrationUrl).'','target' => '_blank','rel' => 'noopener','variant' => 'primary','size' => 'md']); ?>
                  Register
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
              <?php endif; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

      
      <div class="prose prose-neutral max-w-none rounded-2xl border border-neutral-200 bg-white p-6
                  dark:prose-invert dark:border-neutral-800 dark:bg-neutral-900">
        <?php echo $contentHtml; ?>

      </div>

      
      <div class="rounded-2xl border border-neutral-200 bg-white p-4 text-sm text-neutral-600
                  dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-300">
        <div class="flex flex-wrap gap-x-6 gap-y-2">
          <div><span class="font-medium text-neutral-900 dark:text-neutral-100">Ends/day:</span> <?php echo e($league->ends_per_day); ?></div>
          <div><span class="font-medium text-neutral-900 dark:text-neutral-100">Arrows/end:</span> <?php echo e($league->arrows_per_end); ?></div>
          <div><span class="font-medium text-neutral-900 dark:text-neutral-100">X-ring value:</span> <?php echo e($league->x_ring_value); ?></div>
          <div><span class="font-medium text-neutral-900 dark:text-neutral-100">Lanes:</span> <?php echo e($league->lanes_count); ?> (<?php echo e($league->lane_breakdown); ?>)</div>
        </div>
      </div>

      
      <div class="flex items-center justify-between">
        <a href="<?php echo e(route('home')); ?>"
           class="text-sm text-neutral-600 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-neutral-200">
          ← Back to home
        </a>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/archerdb.cloud/public/resources/views/landing/league-info.blade.php ENDPATH**/ ?>