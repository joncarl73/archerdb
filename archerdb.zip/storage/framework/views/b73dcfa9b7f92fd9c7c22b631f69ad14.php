<?php

use Livewire\Volt\Component;
use App\Models\TrainingSession;

?>

<section class="w-full">
    <div class="mx-auto max-w-7xl">
        <div class="sm:flex sm:items-center">
            <div class="sm:flex-auto">
                <h1 class="text-base font-semibold text-gray-900 dark:text-white">
                    Session stats
                </h1>
                <p class="mt-2 text-sm text-gray-700 dark:text-gray-300">
                    <?php echo e($session->title ?? 'Session'); ?> — <?php echo e($session->distance_m ? $session->distance_m.'m' : '—'); ?>

                    • <?php echo e($session->arrows_per_end); ?> arrows/end
                    • up to <?php echo e($session->max_score); ?> points/arrow
                    <!--[if BLOCK]><![endif]--><?php if(($session->x_value ?? 10) > $session->max_score): ?>
                        (X=<?php echo e($session->x_value); ?>)
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </p>
            </div>
            <div class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none space-x-2">
                <a href="<?php echo e(route('training.record', $session->id)); ?>" wire:navigate>
                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'ghost','icon' => 'arrow-left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'ghost','icon' => 'arrow-left']); ?>Back to record <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                </a>
                <a href="<?php echo e(route('training.index')); ?>" wire:navigate>
                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'ghost','icon' => 'list-bullet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'ghost','icon' => 'list-bullet']); ?>Back to sessions <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                </a>
            </div>
        </div>

        
        <div class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">Total score</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums">
                    <?php echo e($totalScore); ?> <span class="text-sm font-normal text-gray-500 dark:text-gray-400">/ <?php echo e($maxPossible); ?></span>
                </div>
            </div>
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">X (<?php echo e((int)($session->x_value ?? 10)); ?>)</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums">
                    <?php echo e($xCount); ?> <span class="text-sm font-normal text-gray-500 dark:text-gray-400">(<?php echo e(round(($xCount / max(1, $session->ends->count()*$session->arrows_per_end))*100,1)); ?>%)</span>
                </div>
            </div>
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">Avg / arrow</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums"><?php echo e($avgPerArrow); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">Avg / end • σ</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums"><?php echo e($avgPerEnd); ?> <span class="text-sm font-normal"> • <?php echo e($endStdDev); ?></span></div>
            </div>

            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">10+ (incl. X)</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums"><?php echo e($tenPlusCount); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">Misses</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums"><?php echo e($missCount); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">Best end</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums">#<?php echo e($bestEndNumber); ?> • <?php echo e($bestEnd); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                <div class="text-sm text-gray-500 dark:text-gray-400">Worst end</div>
                <div class="mt-1 text-2xl font-semibold tabular-nums">#<?php echo e($worstEndNumber); ?> • <?php echo e($worstEnd); ?></div>
            </div>
        </div>

        
        <div class="mt-8 grid gap-6 lg:grid-cols-2">
            
            <div
                x-data="{
                  chart:null,
                  data:<?php echo \Illuminate\Support\Js::from($endSeries)->toHtml() ?>,
                  maxEnd: <?php echo e((int)$session->arrows_per_end * max((int)$session->max_score, (int)($session->x_value ?? 10))); ?>,
                  options() {
                    const dark = document.documentElement.classList.contains('dark');
                    return {
                      chart:{ type:'area', height:280, toolbar:{show:false}, foreColor: dark ? '#e5e7eb' : '#374151' },
                      theme:{ mode: dark ? 'dark' : 'light' },
                      series:[{ name:'End total', data: this.data }],
                      xaxis:{ type:'category', title:{ text:'End' } },
                      yaxis:{ min:0, max:this.maxEnd },
                      dataLabels:{ enabled:false },
                      stroke:{ curve:'smooth', width:2 },
                      annotations:{
                        yaxis:[{ y:this.maxEnd, borderColor:'#94a3b8', label:{ text:'Max per end' } }]
                      }
                    }
                  },
                  init(){ this.chart = new ApexCharts(this.$refs.chart, this.options()); this.chart.render(); }
                }"
                class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700"
            >
                <div class="mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">End totals</div>
                <div x-ref="chart"></div>
            </div>

            
            <div
                x-data="{
                  chart:null,
                  cum:<?php echo \Illuminate\Support\Js::from($cumSeries)->toHtml() ?>,
                  perfect:<?php echo \Illuminate\Support\Js::from($perfectPace)->toHtml() ?>,
                  options() {
                    const dark = document.documentElement.classList.contains('dark');
                    return {
                      chart:{ type:'line', height:280, toolbar:{show:false}, foreColor: dark ? '#e5e7eb' : '#374151' },
                      theme:{ mode: dark ? 'dark' : 'light' },
                      series:[
                        { name:'Cumulative', data: this.cum },
                        { name:'Perfect pace', data: this.perfect }
                      ],
                      xaxis:{ type:'category', title:{ text:'End' } },
                      yaxis:{ min:0 },
                      dataLabels:{ enabled:false },
                      stroke:{ curve:'smooth', width:[3,2], dashArray:[0,5] },
                      legend:{ position:'bottom' }
                    }
                  },
                  init(){ this.chart = new ApexCharts(this.$refs.chart, this.options()); this.chart.render(); }
                }"
                class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700"
            >
                <div class="mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Cumulative score</div>
                <div x-ref="chart"></div>
            </div>

            
            <div
                x-data="{
                  chart:null,
                  options(){
                    const dark = document.documentElement.classList.contains('dark');
                    return {
                      chart:{ type:'donut', height:300, toolbar:{show:false}, foreColor: dark ? '#e5e7eb' : '#374151' },
                      theme:{ mode: dark ? 'dark' : 'light' },
                      labels: <?php echo \Illuminate\Support\Js::from($distLabels)->toHtml() ?>,
                      series: <?php echo \Illuminate\Support\Js::from($distSeries)->toHtml() ?>,
                      legend:{ position:'bottom' }
                    }
                  },
                  init(){ this.chart = new ApexCharts(this.$refs.chart, this.options()); this.chart.render(); }
                }"
                class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700 lg:col-span-2"
            >
                <div class="mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Score distribution</div>
                <div x-ref="chart"></div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Development\web_sites\archerdb\resources\views\livewire/training/stats.blade.php ENDPATH**/ ?>