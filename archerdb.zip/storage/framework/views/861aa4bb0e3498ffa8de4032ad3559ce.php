
<?php if (isset($component)) { $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.public','data' => ['league' => $league]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['league' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($league)]); ?>
  <?php
    // Inputs flashed by controller:
    // $name, $repeat, $week, $lane, $checkinId

    $mode = $league->scoring_mode->value ?? $league->scoring_mode;

    // Resolve the selected week's scheduled date (if week number is present)
    $weekRow = null;
    if (!empty($week)) {
        $weekRow = \App\Models\LeagueWeek::where('league_id', $league->id)
                    ->where('week_number', (int) $week)
                    ->first();
    }
    $today    = \Illuminate\Support\Carbon::today();
    $weekDate = $weekRow ? \Illuminate\Support\Carbon::parse($weekRow->date) : null;

    // NEW: Decide PD vs kiosk
    // - If league is personal_device => always PD
    // - Else (kiosk/tablet) => PD only when today != scheduled date for that week
    $usePersonalDevice = ($mode === 'personal_device')
        || ($weekDate ? !$today->isSameDay($weekDate) : true);

    // Build Start URL (PD path: append ?pd=1 only when league mode is NOT personal_device)
    $baseStart = ($checkinId ?? null)
      ? route('public.scoring.start', [$league->public_uuid, $checkinId])
      : null;

    $startUrl = null;
    if ($baseStart && $usePersonalDevice) {
        $startUrl = ($mode === 'personal_device') ? $baseStart : $baseStart.'?pd=1';
    }

    // Back to picker
    $backUrl = route('public.checkin.participants', ['uuid' => $league->public_uuid]);
  ?>

  <section class="w-full py-10">
    <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
      <div class="text-center">
        <h1 class="text-xl font-semibold text-zinc-900 dark:text-zinc-100">
          <?php echo e($name ? "Thanks, {$name}!" : 'Check-in complete'); ?>

        </h1>

        <?php if($repeat): ?>
          <p class="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
            You’re already checked in<?php echo e($week ? " for week {$week}" : ''); ?><?php echo e($lane ? " • Lane {$lane}" : ''); ?>.
          </p>
        <?php else: ?>
          <p class="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
            You’re checked in<?php echo e($week ? " for week {$week}" : ''); ?><?php echo e($lane ? " • Lane {$lane}" : ''); ?>.
          </p>
        <?php endif; ?>

        
        <?php if($startUrl): ?>
          <div class="mt-6 flex items-center justify-center gap-3">
            <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($startUrl).'','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($startUrl).'','variant' => 'primary']); ?>
              Start scoring
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($backUrl).'','variant' => 'ghost']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($backUrl).'','variant' => 'ghost']); ?>
              Choose a different archer
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
          </div>

          <?php if($mode !== 'personal_device'): ?>
            <p class="mt-3 text-xs text-zinc-500 dark:text-zinc-400">
              Using <span class="font-medium">personal-device scoring</span> because today is not the scheduled league night for this week.
            </p>
          <?php endif; ?>
        <?php else: ?>
          
          <div class="mt-6 space-y-2">
            <?php if($checkinId && $mode !== 'personal_device'): ?>
              <p class="text-sm text-zinc-600 dark:text-zinc-400">
                It’s league night for Week <?php echo e($week); ?>. Please use the kiosk tablet at your lane to enter scores.
              </p>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($backUrl).'','variant' => 'ghost']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($backUrl).'','variant' => 'ghost']); ?>
              Back to check-in
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="mt-8 rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
        <dl class="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <dt class="text-xs uppercase tracking-wide text-zinc-500 dark:text-zinc-400">League</dt>
            <dd class="mt-1 text-sm font-medium text-zinc-900 dark:text-zinc-100"><?php echo e($league->title); ?></dd>
          </div>
          <div>
            <dt class="text-xs uppercase tracking-wide text-zinc-500 dark:text-zinc-400">Week</dt>
            <dd class="mt-1 text-sm font-medium text-zinc-900 dark:text-zinc-100"><?php echo e($week ?? '—'); ?></dd>
          </div>
          <div>
            <dt class="text-xs uppercase tracking-wide text-zinc-500 dark:text-zinc-400">Lane</dt>
            <dd class="mt-1 text-sm font-medium text-zinc-900 dark:text-zinc-100"><?php echo e($lane ?? '—'); ?></dd>
          </div>
        </dl>
        <?php if($weekDate): ?>
          <p class="mt-3 text-xs text-zinc-500 dark:text-zinc-400">
            Scheduled date for Week <?php echo e($week); ?>: <?php echo e($weekDate->toFormattedDateString()); ?>.
          </p>
        <?php endif; ?>
      </div>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $attributes = $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $component = $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/public/checkin/ok.blade.php ENDPATH**/ ?>