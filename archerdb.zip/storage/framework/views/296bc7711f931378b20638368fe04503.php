<!--[if BLOCK]><![endif]--><?php if($sent): ?>
  <div class="rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800 ring-1 ring-inset ring-emerald-200
              dark:bg-emerald-900/20 dark:text-emerald-200 dark:ring-emerald-900/40">
    Thanks! Your message has been sent.
  </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<!--[if BLOCK]><![endif]--><?php if($sendError): ?>
  <div class="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-800 ring-1 ring-inset ring-rose-200
              dark:bg-rose-900/20 dark:text-rose-200 dark:ring-rose-900/40">
    <?php echo e($sendError); ?>

  </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<form wire:submit.prevent="send" class="space-y-4" autocomplete="off">
  
  <div class="sr-only" aria-hidden="true">
    <label>Website</label>
    <input type="text" wire:model.lazy="website" tabindex="-1" autocomplete="off" />
  </div>

  <div>
    <label class="block text-sm font-medium text-neutral-700 dark:text-neutral-200">Name</label>
    <input type="text" wire:model.defer="name" autocomplete="name"
           class="mt-1 block w-full rounded-md border border-neutral-300 px-3 py-2 shadow-sm
                  focus:border-primary-500 focus:ring-primary-500 sm:text-sm
                  dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-100">
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
  </div>

  <div>
    <label class="block text-sm font-medium text-neutral-700 dark:text-neutral-200">Email</label>
    <input type="email" wire:model.defer="email" autocomplete="email"
           class="mt-1 block w-full rounded-md border border-neutral-300 px-3 py-2 shadow-sm
                  focus:border-primary-500 focus:ring-primary-500 sm:text-sm
                  dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-100">
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
  </div>

  <div>
    <label class="block text-sm font-medium text-neutral-700 dark:text-neutral-200">Message</label>
    <textarea rows="5" wire:model.defer="message"
              class="mt-1 block w-full rounded-md border border-neutral-300 px-3 py-2 shadow-sm
                     focus:border-primary-500 focus:ring-primary-500 sm:text-sm
                     dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-100"></textarea>
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
  </div>

  <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['type' => 'submit','variant' => 'primary','size' => 'sm','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary','size' => 'sm','wire:loading.attr' => 'disabled']); ?>
    <span wire:loading.remove>Send message</span>
    <span wire:loading>Sending…</span>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
</form><?php /**PATH /var/www/archerdb.cloud/public/resources/views/livewire/landing/contact-form.blade.php ENDPATH**/ ?>