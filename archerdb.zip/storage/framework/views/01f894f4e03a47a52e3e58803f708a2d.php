


<?php $__env->startSection('title', 'ArcherDB — Archery training & league scoring'); ?>

<?php $__env->startPush('meta'); ?>
  <meta name="description" content="ArcherDB helps archers train smarter, score faster, and run leagues with live results." />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  
  <section class="relative overflow-hidden">
    
    <div class="absolute inset-0 -z-10">
      <img 
        src="<?php echo e(asset('img/hero-bg.png')); ?>" 
        alt="Archery background" 
        class="h-full w-full object-cover"
      >
      
      <div class="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-white dark:from-black/60 dark:via-black/40 dark:to-neutral-950"></div>
    </div>

    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-28 relative">
      <div class="max-w-3xl">
        <p class="mb-3 inline-flex items-center gap-2 rounded-full border border-neutral-200 px-3 py-1 text-xs font-medium text-neutral-100 dark:border-neutral-800 dark:text-neutral-300 bg-black/30 backdrop-blur-sm">
          <span class="h-2 w-2 rounded-full bg-primary-400"></span>
          Public beta in progress
        </p>
        <h1 class="text-4xl font-extrabold tracking-tight sm:text-6xl text-white">
          Train smarter. <span class="text-primary-400">Score faster.</span> Compete together.
        </h1>
        <p class="mt-6 text-base sm:text-lg text-neutral-200 dark:text-neutral-300">
          Personal training, rich stats, and league scoring—built for clubs, coaches, and competitive archers.
        </p>
        <div class="mt-8 flex flex-col sm:flex-row gap-3">
          <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e(route('register')).'','variant' => 'primary','color' => 'red','icon' => 'check-circle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e(route('register')).'','variant' => 'primary','color' => 'red','icon' => 'check-circle']); ?>
              Get Started Free
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => '#features','variant' => 'primary','color' => 'blue','icon' => 'information-circle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => '#features','variant' => 'primary','color' => 'blue','icon' => 'information-circle']); ?>
              Learn More
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
        </div>
      </div>
    </div>
  </section>


  
  <section id="features" class="py-16 sm:py-24">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="mx-auto max-w-2xl text-center">
        <h2 class="text-3xl font-bold sm:text-4xl">Everything for archers & leagues</h2>
        <p class="mt-3 text-neutral-600 dark:text-neutral-300">From solo practice to club nights and corporate leagues.</p>
      </div>

      <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <?php $__currentLoopData = [
          ['title' => 'Personal Training', 'desc' => 'Per-end scoring, X/10/9 counts, auto summaries.'],
          ['title' => 'Live League Scoring', 'desc' => 'Kiosk & personal modes with public boards.'],
          ['title' => 'Flexible Targets', 'desc' => 'WA 40cm triple-spot, single-spot, compound/recurve.'],
          ['title' => 'Stats & Insights', 'desc' => 'PRs, groupings, X-rate, trends, distance splits.'],
          ['title' => 'Mobile-Ready', 'desc' => 'Phones, tablets, and kiosk screens.'],
          ['title' => 'Team Tools', 'desc' => 'Events, lanes, registrations, results.'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="rounded-2xl border border-neutral-200 p-6 dark:border-neutral-800">
            <div class="mb-3 h-9 w-9 rounded-xl bg-primary-600/10 dark:bg-primary-500/10"></div>
            <h3 class="font-semibold"><?php echo e($f['title']); ?></h3>
            <p class="mt-2 text-sm text-neutral-600 dark:text-neutral-300"><?php echo e($f['desc']); ?></p>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>

  
  <section id="partners" class="py-10 sm:py-12 bg-neutral-50 dark:bg-neutral-900">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="mx-auto max-w-2xl text-center">
        <h2 class="text-sm font-semibold tracking-wider text-neutral-500 dark:text-neutral-400 uppercase">
          Trusted by clubs & partners
        </h2>
      </div>

      
      <div class="mt-8 grid grid-cols-2 gap-x-8 gap-y-8 sm:grid-cols-3 lg:grid-cols-6">
        <?php $__currentLoopData = [
          ['src'=>'/img/partners/lancaster_archery_academy.jpg','alt'=>'Lancaster Archery Academy'],
          ['src'=>'/img/partners/lancaster_archery_supply.jpg','alt'=>'Lancaster Archery Supply'],
          ['src'=>'/img/partners/easton.jpg','alt'=>'Easton Archery'],
          ['src'=>'/img/partners/lancaster_archery_academy.jpg','alt'=>'Lancaster Archery Academy'],
          ['src'=>'/img/partners/lancaster_archery_supply.jpg','alt'=>'Lancaster Archery Supply'],
          ['src'=>'/img/partners/easton.jpg','alt'=>'Easton Archery'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="flex items-center justify-center">
            <img
              src="<?php echo e($p['src']); ?>"
              alt="<?php echo e($p['alt']); ?>"
              class="max-h-full w-auto grayscale opacity-60 hover:opacity-90 transition-opacity duration-200
                    dark:brightness-125"
            />
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      
      <p class="mt-6 text-center text-xs text-neutral-500 dark:text-neutral-400">
        Logos shown are for placement only and may include current or prospective partners.
      </p>
    </div>
  </section>


  
  <section class="relative py-16 sm:py-24 overflow-hidden">
    <div class="absolute inset-0 -z-10">
      
      
      <div class="h-full w-full bg-gradient-to-b from-neutral-50 to-white dark:from-neutral-900 dark:to-neutral-950"></div>
    </div>

    <div class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
      <h2 class="text-3xl font-bold sm:text-4xl">Ready to shoot higher scores?</h2>
      <p class="mt-3 text-neutral-600 dark:text-neutral-300">
        Create your account and start a session in under a minute.
      </p>
      <div class="mt-8">
        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e(route('register')).'','variant' => 'primary','color' => 'yellow','icon' => 'hand-thumb-up']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e(route('register')).'','variant' => 'primary','color' => 'yellow','icon' => 'hand-thumb-up']); ?>
          Create Free Account
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
      </div>
    </div>
  </section>


  
  <section id="pricing" class="py-16 sm:py-24">
    <div class="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
      <div class="mx-auto max-w-2xl text-center">
        <h2 class="text-3xl font-bold sm:text-4xl">Simple pricing</h2>
        <p class="mt-3 text-neutral-600 dark:text-neutral-300">Start free. Upgrade when your club is ready.</p>
      </div>
      <div class="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <?php $__currentLoopData = [
          ['name'=>'Personal','price'=>'Free','features'=>['Unlimited sessions','Basic stats','Mobile scoring']],
          ['name'=>'Club','price'=>'$29/mo','features'=>['Leagues & lanes','Live boards','Registrations']],
          ['name'=>'Enterprise','price'=>'Contact','features'=>['SLA support','SSO / SAML','Custom reporting']],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="rounded-2xl border border-neutral-200 p-6 dark:border-neutral-800">
            <h3 class="text-lg font-semibold"><?php echo e($p['name']); ?></h3>
            <p class="mt-2 text-2xl font-extrabold"><?php echo e($p['price']); ?></p>
            <ul class="mt-4 space-y-2 text-sm text-neutral-600 dark:text-neutral-300">
              <?php $__currentLoopData = $p['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex items-start gap-2">
                  <span class="mt-1 h-1.5 w-1.5 rounded-full bg-primary-600 dark:bg-primary-500"></span>
                  <span><?php echo e($feat); ?></span>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <a href="<?php echo e(route('register')); ?>" class="mt-6 inline-flex w-full items-center justify-center rounded-xl bg-neutral-900 px-4 py-2 text-white hover:bg-neutral-800 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-white">
              Choose <?php echo e($p['name']); ?>

            </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>

  
  <section id="events" class="py-16 sm:py-24 bg-neutral-50 dark:bg-neutral-900">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="mx-auto max-w-2xl text-center">
        <h2 class="text-3xl font-bold sm:text-4xl">Upcoming events</h2>
        <p class="mt-3 text-neutral-600 dark:text-neutral-300">
          Registration windows currently open and opening soon.
        </p>
      </div>

      <div class="mt-10">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing.upcoming-events', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2375369063-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/archerdb.cloud/public/resources/views/landing/index.blade.php ENDPATH**/ ?>