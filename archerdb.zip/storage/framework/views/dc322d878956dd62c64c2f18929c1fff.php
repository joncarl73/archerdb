<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php echo e($league->title); ?> – Scoring Sheet</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 8px; color: #111; }
        h1 { font-size: 18px; margin: 0 0 6px; }
        .meta { color:#555; margin-bottom: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 6px 8px; }
        th { background: #f5f5f5; text-align: left; white-space: nowrap; }
        td.num { text-align: right; }
        .name { width: 28%; }
        .total { background: #fafafa; font-weight: bold; }
        .muted { color:#777; font-size: 8px; }
    </style>
</head>
<body>
    <h1><?php echo e($league->title); ?> – Scoring Sheet</h1>
    <div class="meta">
        Location: <?php echo e($league->location ?: '—'); ?> • Starts: <?php echo e(optional($league->start_date)->format('Y-m-d') ?: '—'); ?> • Weeks: <?php echo e($league->length_weeks); ?>

    </div>

    <table>
        <thead>
            <tr>
                <th class="name">Archer</th>
                <?php $__currentLoopData = $league->weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th>
                        W <?php echo e($w->week_number); ?><br>
                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th class="total">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php echo e($r['name']); ?>

                    </td>
                    <?php $__currentLoopData = $league->weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $v = $r['weeks'][$w->week_number] ?? 0; ?>
                        <td class="num"><?php echo e($v); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td class="num total"><?php echo e($r['seasonTotal']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="<?php echo e($league->weeks->count() + 2); ?>">No participants.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/pdf/league-scoring-sheet.blade.php ENDPATH**/ ?>