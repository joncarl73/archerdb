<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $league->info->title ?? $league->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($league->info->title ?? $league->title)]); ?>
    <div class="mx-auto w-full max-w-5xl space-y-6">

        
        <?php if($bannerUrl): ?>
            <div class="overflow-hidden rounded-xl ring-1 ring-black/5">
                <img src="<?php echo e($bannerUrl); ?>" alt="<?php echo e($league->title); ?> banner" class="h-64 w-full object-cover sm:h-80 md:h-64">
            </div>
        <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="rounded-md border border-rose-200 bg-rose-50 p-3 text-sm text-rose-900 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-200">
                <div class="font-semibold mb-1">Unable to start registration:</div>
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="rounded-md border border-rose-200 bg-rose-50 p-3 text-sm text-rose-900 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-200">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <div class="rounded-xl border border-neutral-200 bg-white p-5 dark:border-white/10 dark:bg-neutral-900">
            <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <h1 class="text-xl font-semibold text-neutral-900 dark:text-neutral-100">
                        <?php echo e($league->info->title ?? $league->title); ?>

                    </h1>
                    <p class="mt-1 text-sm text-neutral-600 dark:text-neutral-400">
                        <?php echo e($league->location ?: '—'); ?> •
                        <?php echo e(ucfirst($league->type->value ?? $league->type)); ?> League •
                        Starts <?php echo e(optional($league->start_date)->format('Y-m-d') ?: '—'); ?> •
                        <?php echo e($league->length_weeks); ?> weeks
                    </p>
                </div>

                
                <div class="mt-2 sm:mt-0">
                    <?php
                        $fmt          = fn($d) => $d ? $d->format('Y-m-d') : null;

                        $typeVal      = ($league->type->value ?? $league->type);
                        $isClosed     = $typeVal === 'closed';
                        $isOpen       = $typeVal === 'open';

                        $priceCents   = $league->price_cents;
                        $currency     = strtoupper($league->currency ?? 'USD');
                        $priceDisplay = $priceCents !== null ? number_format($priceCents / 100, 2) : null;

                        // Is the current user already registered for this league?
                        $alreadyRegistered = false;
                        if (auth()->check()) {
                            $uid = auth()->id();
                            $email = auth()->user()->email;
                            $alreadyRegistered = \App\Models\LeagueParticipant::query()
                                ->where('league_id', $league->id)
                                ->where(function ($q) use ($uid, $email) {
                                    $q->where('user_id', $uid)
                                      ->orWhere(function ($qq) use ($email) {
                                          if ($email) {
                                              $qq->where('email', $email);
                                          }
                                      });
                                })
                                ->exists();
                        }
                    ?>

                    
                    <?php if($alreadyRegistered): ?>
                        <div class="inline-flex items-center gap-2 rounded-md bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-800 ring-1 ring-inset ring-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-200 dark:ring-emerald-900/40">
                            <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-7.5 9.5a.75.75 0 01-1.127.062l-3.5-3.5a.75.75 0 011.06-1.06l2.88 2.88 6.98-8.844a.75.75 0 011.064-.09z"/>
                            </svg>
                            Registered for this event
                        </div>
                        <?php if(isset($start) || isset($end)): ?>
                            <div class="mt-1 text-right text-xs text-neutral-500 dark:text-neutral-400">
                                <?php if(!empty($start)): ?> Opens <?php echo e($fmt($start)); ?>. <?php endif; ?>
                                <?php if(!empty($end)): ?> Closes <?php echo e($fmt($end)); ?>. <?php endif; ?>
                            </div>
                        <?php endif; ?>

                    <?php else: ?>
                        
                        <?php if($isClosed): ?>
                            <?php if($window === 'during'): ?>
                                <?php if($priceDisplay): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <form method="POST" action="<?php echo e(route('checkout.league.start', ['league' => $league->public_uuid])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button
                                                type="submit"
                                                class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed dark:bg-indigo-500 dark:hover:bg-indigo-400"
                                            >
                                                Register now — <?php echo e($currency); ?> <?php echo e($priceDisplay); ?>

                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>?redirect=<?php echo e(urlencode(request()->fullUrl())); ?>"
                                           class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-400">
                                            Log in to register — <?php echo e($currency); ?> <?php echo e($priceDisplay); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if(isset($start) || isset($end)): ?>
                                        <div class="mt-1 text-right text-xs text-neutral-500 dark:text-neutral-400">
                                            <?php if(!empty($start)): ?> Opens <?php echo e($fmt($start)); ?>. <?php endif; ?>
                                            <?php if(!empty($end)): ?> Closes <?php echo e($fmt($end)); ?>. <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900 ring-1 ring-inset ring-amber-200 dark:bg-amber-900/20 dark:text-amber-200 dark:ring-amber-900/40">
                                        Registration product isn’t configured yet. Set a price on the info page.
                                    </div>
                                <?php endif; ?>
                            <?php elseif($window === 'before'): ?>
                                <div class="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900 ring-1 ring-inset ring-amber-200 dark:bg-amber-900/20 dark:text-amber-200 dark:ring-amber-900/40">
                                    Registration opens <?php echo e($fmt($start ?? null)); ?>.
                                </div>
                            <?php elseif($window === 'after'): ?>
                                <div class="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-900 ring-1 ring-inset ring-rose-200 dark:bg-rose-900/20 dark:text-rose-200 dark:ring-rose-900/40">
                                    Registration closed<?php echo e(!empty($end) ? ' on '.$fmt($end) : ''); ?>.
                                </div>
                            <?php else: ?>
                                
                                <?php if($priceDisplay): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <form method="POST" action="<?php echo e(route('checkout.league.start', ['league' => $league->public_uuid])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button
                                                type="submit"
                                                class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-400"
                                            >
                                                Register — <?php echo e($currency); ?> <?php echo e($priceDisplay); ?>

                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>?redirect=<?php echo e(urlencode(request()->fullUrl())); ?>"
                                           class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-400">
                                            Log in to register — <?php echo e($currency); ?> <?php echo e($priceDisplay); ?>

                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>

                        
                        <?php if($isOpen): ?>
                            <?php if($window === 'during'): ?>
                                <?php if($registrationUrl): ?>
                                    <a href="<?php echo e($registrationUrl); ?>" target="_blank" rel="noopener"
                                       class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-400">
                                        Register now
                                        <svg class="ml-2 h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M12.293 2.293a1 1 0 011.414 0l4 4a.997.997 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a.997.997 0 010-1.414l8-8zM5 13l2 2 8-8-2-2-8 8z"/>
                                        </svg>
                                    </a>
                                    <?php if(isset($start) || isset($end)): ?>
                                        <div class="mt-1 text-right text-xs text-neutral-500 dark:text-neutral-400">
                                            <?php if(!empty($start)): ?> Opens <?php echo e($fmt($start)); ?>. <?php endif; ?>
                                            <?php if(!empty($end)): ?> Closes <?php echo e($fmt($end)); ?>. <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800 ring-1 ring-inset ring-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-200 dark:ring-emerald-900/40">
                                        Registration is open.
                                        <?php if(!empty($end)): ?> Closes <?php echo e($fmt($end)); ?>. <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php elseif($window === 'before'): ?>
                                <div class="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900 ring-1 ring-inset ring-amber-200 dark:bg-amber-900/20 dark:text-amber-200 dark:ring-amber-900/40">
                                    Registration opens <?php echo e($fmt($start ?? null)); ?>.
                                </div>
                            <?php elseif($window === 'after'): ?>
                                <div class="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-900 ring-1 ring-inset ring-rose-200 dark:bg-rose-900/20 dark:text-rose-200 dark:ring-rose-900/40">
                                    Registration closed<?php echo e(!empty($end) ? ' on '.$fmt($end) : ''); ?>.
                                </div>
                            <?php else: ?>
                                
                                <?php if($registrationUrl): ?>
                                    <a href="<?php echo e($registrationUrl); ?>" target="_blank" rel="noopener"
                                       class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-400">
                                        Register
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="prose prose-neutral max-w-none rounded-xl border border-neutral-200 bg-white p-5 dark:prose-invert dark:border-white/10 dark:bg-neutral-900">
            <?php echo $contentHtml; ?>

        </div>

        
        <div class="rounded-xl border border-neutral-200 bg-white p-4 text-sm text-neutral-600 dark:border-white/10 dark:bg-neutral-900 dark:text-neutral-300">
            <div class="flex flex-wrap gap-x-6 gap-y-2">
                <div><span class="font-medium text-neutral-900 dark:text-neutral-100">Ends/day:</span> <?php echo e($league->ends_per_day); ?></div>
                <div><span class="font-medium text-neutral-900 dark:text-neutral-100">Arrows/end:</span> <?php echo e($league->arrows_per_end); ?></div>
                <div><span class="font-medium text-neutral-900 dark:text-neutral-100">X-ring value:</span> <?php echo e($league->x_ring_value); ?></div>
                <div><span class="font-medium text-neutral-900 dark:text-neutral-100">Lanes:</span> <?php echo e($league->lanes_count); ?> (<?php echo e($league->lane_breakdown); ?>)</div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/public/league-info.blade.php ENDPATH**/ ?>