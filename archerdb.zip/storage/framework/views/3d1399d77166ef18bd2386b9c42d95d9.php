<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'value', 'sub' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'value', 'sub' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="rounded-xl border border-zinc-200 bg-white p-5 shadow-sm dark:border-zinc-700 dark:bg-zinc-900">
  <div class="text-sm text-zinc-500 dark:text-zinc-400"><?php echo e($label); ?></div>
  <div class="mt-1 text-2xl font-semibold text-zinc-900 dark:text-zinc-100 tabular-nums">
    <?php echo e($value); ?>

  </div>
  <?php if($sub): ?>
    <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400"><?php echo e($sub); ?></div>
  <?php endif; ?>
</div>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/components/stat-card.blade.php ENDPATH**/ ?>