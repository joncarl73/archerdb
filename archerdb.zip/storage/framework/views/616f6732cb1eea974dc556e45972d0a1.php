
<footer class="border-t border-neutral-200 dark:border-neutral-800">
  <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
    <div class="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
      <div class="flex items-center gap-2">
        <?php if (isset($component)) { $__componentOriginal87f224b29228128a49d30612ade21da8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87f224b29228128a49d30612ade21da8 = $attributes; } ?>
<?php $component = App\View\Components\ArcherdbLogo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('archerdb-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ArcherdbLogo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87f224b29228128a49d30612ade21da8)): ?>
<?php $attributes = $__attributesOriginal87f224b29228128a49d30612ade21da8; ?>
<?php unset($__attributesOriginal87f224b29228128a49d30612ade21da8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87f224b29228128a49d30612ade21da8)): ?>
<?php $component = $__componentOriginal87f224b29228128a49d30612ade21da8; ?>
<?php unset($__componentOriginal87f224b29228128a49d30612ade21da8); ?>
<?php endif; ?>
        <span class="font-semibold">ArcherDB</span>
      </div>
      <nav class="text-sm flex flex-wrap gap-4 text-neutral-600 dark:text-neutral-300">
        <a href="/contact">Contact Us</a>
        <a href="/privacy">Privacy</a>
        <a href="/terms">Terms</a>
      </nav>
    </div>
    <p class="mt-6 text-xs text-neutral-500 dark:text-neutral-400">&copy; <?php echo e(date('Y')); ?> ArcherDB. All rights reserved.</p>
  </div>
</footer>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/landing/partials/footer.blade.php ENDPATH**/ ?>