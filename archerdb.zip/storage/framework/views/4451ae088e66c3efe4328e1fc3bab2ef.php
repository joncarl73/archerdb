<?php

use App\Models\KioskSession;
use App\Models\League;
use App\Models\LeagueCheckin;
use App\Models\LeagueWeek;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Str;
use Livewire\Volt\Component;

?>

<section class="w-full">
    <div class="mx-auto max-w-7xl">
        
        <div class="sm:flex sm:items-center">
            <div class="sm:flex-auto">
                <h1 class="text-base font-semibold text-gray-900 dark:text-white">
                    <?php echo e($league->title); ?> — Kiosk Sessions
                </h1>
                <p class="mt-2 text-sm text-gray-700 dark:text-gray-300">
                    Assign a tablet to specific archers (checked in for the selected week) and share the tokenized URL.
                </p>
            </div>
            <div class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
                <a href="<?php echo e(route('corporate.leagues.show', $league)); ?>"
                   class="rounded-md bg-white px-3 py-2 text-sm font-medium inset-ring inset-ring-gray-300 hover:bg-gray-50
                          dark:bg-white/5 dark:text-gray-200 dark:inset-ring-white/10 dark:hover:bg-white/10">
                    Back to League
                </a>
            </div>
        </div>

        
        <!--[if BLOCK]><![endif]--><?php if($createdToken): ?>
            <?php ($kioskUrl = url('/k/'.$createdToken)); ?>
            <div class="mt-4 rounded-xl border border-emerald-300/40 bg-emerald-50 p-4 text-emerald-900
                        dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-200">
                <div class="font-medium">Kiosk session created</div>
                <div class="mt-1 text-sm">
                    Tablet URL:
                    <a class="underline hover:no-underline" href="<?php echo e($kioskUrl); ?>" target="_blank" rel="noopener">
                        <?php echo e($kioskUrl); ?>

                    </a>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <div class="mt-6 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm dark:border-white/10 dark:bg-white/5">
            <h2 class="text-base font-semibold text-gray-900 dark:text-white">Create kiosk session</h2>
            <p class="mt-1 text-sm text-gray-700 dark:text-gray-300">
                Pick a week, then select one or more archers who have checked in.
            </p>

            <form wire:submit.prevent="createSession" class="mt-5 space-y-6">
                
                <div>
                    <?php if (isset($component)) { $__componentOriginal8a84eac5abb8af1e2274971f8640b38f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a84eac5abb8af1e2274971f8640b38f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::label','data' => ['for' => 'week_number']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'week_number']); ?>Week <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a84eac5abb8af1e2274971f8640b38f)): ?>
<?php $attributes = $__attributesOriginal8a84eac5abb8af1e2274971f8640b38f; ?>
<?php unset($__attributesOriginal8a84eac5abb8af1e2274971f8640b38f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a84eac5abb8af1e2274971f8640b38f)): ?>
<?php $component = $__componentOriginal8a84eac5abb8af1e2274971f8640b38f; ?>
<?php unset($__componentOriginal8a84eac5abb8af1e2274971f8640b38f); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginala467913f9ff34913553be64599ec6e92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala467913f9ff34913553be64599ec6e92 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::select.index','data' => ['id' => 'week_number','wire:model.live' => 'week_number','class' => 'mt-2 w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'week_number','wire:model.live' => 'week_number','class' => 'mt-2 w-full']); ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($w['week_number']); ?>">
                                Week <?php echo e($w['week_number']); ?> — <?php echo e(\Illuminate\Support\Carbon::parse($w['date'])->toFormattedDateString()); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala467913f9ff34913553be64599ec6e92)): ?>
<?php $attributes = $__attributesOriginala467913f9ff34913553be64599ec6e92; ?>
<?php unset($__attributesOriginala467913f9ff34913553be64599ec6e92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala467913f9ff34913553be64599ec6e92)): ?>
<?php $component = $__componentOriginala467913f9ff34913553be64599ec6e92; ?>
<?php unset($__componentOriginala467913f9ff34913553be64599ec6e92); ?>
<?php endif; ?>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['week_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div>
                    <div class="flex items-center justify-between">
                        <label class="block text-sm font-medium text-gray-800 dark:text-gray-200">Archers checked in</label>
                        <div class="text-xs text-gray-500 dark:text-gray-400">Select one or more</div>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if(count($participantsForWeek)): ?>
                        <div class="mt-2 grid gap-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $participantsForWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="flex items-center gap-2 rounded-lg border border-gray-200 bg-white p-2 text-sm
                                               dark:border-white/10 dark:bg-white/5">
                                    <input type="checkbox"
                                           wire:model.live="participantIds"
                                           value="<?php echo e((int) $p['id']); ?>"
                                           class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 dark:border-gray-600">
                                    <span class="text-gray-800 dark:text-gray-200">
                                        <?php echo e($p['name']); ?>

                                        <!--[if BLOCK]><![endif]--><?php if($p['lane']): ?>
                                            <span class="ml-1 rounded bg-gray-100 px-1.5 py-0.5 text-[11px] text-gray-700 dark:bg-white/10 dark:text-gray-300">
                                                Lane <?php echo e($p['lane']); ?>

                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
                            No available archers to assign for week <?php echo e($week_number); ?>.
                        </p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['participantIds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['participantIds.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-rose-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="flex items-center gap-3">
                    <button type="submit"
                            class="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-xs
                                   hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600
                                   dark:bg-indigo-500 dark:hover:bg-indigo-400 dark:focus-visible:outline-indigo-500"
                            <?php if(count($participantsForWeek) === 0): echo 'disabled'; endif; ?>>
                        Create kiosk session
                    </button>
                    <p class="text-xs text-gray-500 dark:text-gray-400">A unique tokenized URL will be generated.</p>
                </div>
            </form>
        </div>

        
        <div class="mt-8">
            <div class="mb-2 flex items-center justify-between">
                <div class="text-sm text-gray-700 dark:text-gray-300">
                    Showing
                    <!--[if BLOCK]><![endif]--><?php if($showAll): ?>
                        <span class="font-medium">all</span>
                    <?php else: ?>
                        sessions for <span class="font-medium">week <?php echo e($week_number); ?></span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'ghost','size' => 'sm','wire:click' => 'toggleShowAll']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'ghost','size' => 'sm','wire:click' => 'toggleShowAll']); ?>
                    <?php echo e($showAll ? 'Filter by week' : 'Show all'); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
            </div>

            <div class="overflow-hidden rounded-2xl border border-gray-200 shadow-sm dark:border-white/10">
                <table class="w-full text-left">
                    <thead class="bg-white dark:bg-gray-900">
                        <tr>
                            <th class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 dark:text-white">Created</th>
                            <th class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-white">Week</th>
                            <th class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-white">Assigned archers</th>
                            <th class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-white">Status</th>
                            <th class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 dark:text-white">Tablet URL</th>
                            <th class="py-3.5 pl-3 pr-4 text-right"><span class="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-white/10 bg-white dark:bg-transparent">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php ($url = url('/k/'.$s->token)); ?>
                            <?php ($ids = is_array($s->participants) ? $s->participants : (json_decode((string)$s->participants, true) ?: [])); ?>
                            <?php ($rows = \App\Models\LeagueParticipant::where('league_id', $league->id)->whereIn('id', $ids)->get(['id','first_name','last_name'])->keyBy('id')); ?>
                            <?php ($checkins = \App\Models\LeagueCheckin::where('league_id', $league->id)->where('week_number', $s->week_number)->whereIn('participant_id', $ids)->get(['participant_id','lane_number','lane_slot'])->keyBy('participant_id')); ?>
                            <tr>
                                <td class="py-3.5 pl-4 pr-3 text-sm text-gray-800 dark:text-gray-200">
                                    <?php echo e($s->created_at?->format('Y-m-d H:i') ?? '—'); ?>

                                </td>
                                <td class="px-3 py-3.5 text-sm text-gray-800 dark:text-gray-200">
                                    Week <?php echo e($s->week_number); ?>

                                </td>
                                <td class="px-3 py-3.5 text-sm text-gray-800 dark:text-gray-200">
                                    <!--[if BLOCK]><![endif]--><?php if(!empty($ids)): ?>
                                        <div class="flex flex-wrap gap-1">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php ($p = $rows->get($pid)); ?>
                                                <?php ($nm = $p ? trim(($p->first_name ?? '').' '.($p->last_name ?? '')) : '#'.$pid); ?>
                                                <?php ($c = $checkins->get($pid)); ?>
                                                <?php ($lane = null); ?>
                                                <!--[if BLOCK]><![endif]--><?php if($c): ?>
                                                    <?php ($lane = (string) ($c->lane_number ?? '')); ?>
                                                    <!--[if BLOCK]><![endif]--><?php if($lane !== '' && $c->lane_slot && $c->lane_slot !== 'single'): ?>
                                                        <?php ($lane .= $c->lane_slot); ?>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php ($lane = $lane !== '' ? $lane : null); ?>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <span class="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-700 dark:bg-white/10 dark:text-gray-300">
                                                    <?php echo e($nm); ?><!--[if BLOCK]><![endif]--><?php if($lane): ?> — Lane <?php echo e($lane); ?><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="px-3 py-3.5 text-sm">
                                    <!--[if BLOCK]><![endif]--><?php if($s->is_active): ?>
                                        <span class="rounded-md bg-emerald-100 px-2 py-0.5 text-xs text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300">Active</span>
                                    <?php else: ?>
                                        <span class="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-700 dark:bg-white/10 dark:text-gray-300">Inactive</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="px-3 py-3.5 text-sm">
                                    <a href="<?php echo e($url); ?>" class="truncate text-indigo-600 underline hover:no-underline dark:text-indigo-400" target="_blank" rel="noopener">
                                        <?php echo e($url); ?>

                                    </a>
                                </td>
                                <td class="py-3.5 pl-3 pr-4 text-right">
                                    <div class="inline-flex items-center gap-2">
                                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener"
                                           class="rounded-md bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 dark:bg-indigo-500 dark:hover:bg-indigo-400">
                                            Open
                                        </a>
                                        <button type="button"
                                                x-data="{copied:false}"
                                                @click="navigator.clipboard.writeText('<?php echo e($url); ?>'); copied=true; setTimeout(()=>copied=false,1500)"
                                                class="rounded-md bg-white px-3 py-1.5 text-xs font-medium inset-ring inset-ring-gray-300 hover:bg-gray-50
                                                       dark:bg-white/5 dark:text-gray-200 dark:inset-ring-white/10 dark:hover:bg-white/10">
                                            <span x-show="!copied">Copy</span>
                                            <span x-show="copied">Copied!</span>
                                        </button>

                                        
                                        <button wire:click="deleteSession(<?php echo e($s->id); ?>)"
                                                class="rounded-md bg-white px-3 py-1.5 text-xs font-medium text-rose-600 inset-ring inset-ring-gray-300 hover:bg-rose-50
                                                       dark:bg-white/5 dark:text-rose-300 dark:inset-ring-white/10 dark:hover:bg-rose-500/10">
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="py-8 px-4 text-sm text-gray-500 dark:text-gray-400">
                                    No kiosk sessions <?php echo e($showAll ? 'yet' : 'for week '.$week_number); ?>.
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Development\web_sites\archerdb\resources\views\livewire/corporate/kiosks/index.blade.php ENDPATH**/ ?>