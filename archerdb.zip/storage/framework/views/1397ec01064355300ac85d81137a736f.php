<?php

use App\Models\League;
use Carbon\Carbon;
use Livewire\Volt\Component;

?>

<div class="relative overflow-hidden rounded-xl border border-neutral-200 bg-white dark:border-neutral-700 dark:bg-neutral-900">
    <div class="p-4 border-b border-neutral-200 dark:border-white/10">
        <h2 class="text-sm font-semibold text-neutral-900 dark:text-neutral-100">Upcoming events & registration</h2>
        <p class="mt-1 text-xs text-neutral-600 dark:text-neutral-400">
            Showing events with open registration and those opening soon (next <?php echo e($windowDays); ?> days).
        </p>
    </div>

    <div class="p-4 grid grid-cols-1 gap-6 lg:grid-cols-2">
        
        <div class="rounded-lg border border-neutral-200 dark:border-white/10">
            <div class="flex items-center justify-between border-b border-neutral-200 px-4 py-3 dark:border-white/10">
                <h3 class="text-sm font-medium text-neutral-900 dark:text-neutral-100">Open now</h3>
                <span class="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-200 dark:ring-emerald-900/40">
                    <?php echo e($openNow->count()); ?>

                </span>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($openNow->isEmpty()): ?>
                <div class="p-4 text-sm text-neutral-600 dark:text-neutral-300">No events currently open.</div>
            <?php else: ?>
                <ul class="divide-y divide-neutral-200 dark:divide-white/10">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $openNow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $hasUrl = filled($lg->info?->registration_url);
                        ?>
                        <li class="px-4 py-3">
                            <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <div class="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                                        <?php echo e($lg->title); ?>

                                    </div>
                                    <div class="mt-0.5 text-xs text-neutral-600 dark:text-neutral-400">
                                        <?php echo e($lg->location ?: '—'); ?> • Starts <?php echo e($this->fmtYmd($lg->start_date)); ?> • <?php echo e($lg->length_weeks); ?> weeks
                                    </div>
                                    <div class="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                                        <!--[if BLOCK]><![endif]--><?php if($lg->registration_start_date): ?> Opened <?php echo e($this->fmtYmd($lg->registration_start_date)); ?>. <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($lg->registration_end_date): ?> Closes <?php echo e($this->fmtYmd($lg->registration_end_date)); ?>. <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>

                                <div class="flex items-center gap-2">
                                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($this->publicInfoUrl($lg)).'','variant' => 'outline','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($this->publicInfoUrl($lg)).'','variant' => 'outline','size' => 'sm']); ?>
                                        View details
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                                    <!--[if BLOCK]><![endif]--><?php if($hasUrl): ?>
                                        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($lg->info->registration_url).'','target' => '_blank','rel' => 'noopener','variant' => 'primary','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($lg->info->registration_url).'','target' => '_blank','rel' => 'noopener','variant' => 'primary','size' => 'sm']); ?>
                                            Register
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div class="rounded-lg border border-neutral-200 dark:border-white/10">
            <div class="flex items-center justify-between border-b border-neutral-200 px-4 py-3 dark:border-white/10">
                <h3 class="text-sm font-medium text-neutral-900 dark:text-neutral-100">Opening soon</h3>
                <span class="rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-800 ring-1 ring-inset ring-amber-200 dark:bg-amber-900/20 dark:text-amber-200 dark:ring-amber-900/40">
                    <?php echo e($openingSoon->count()); ?>

                </span>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($openingSoon->isEmpty()): ?>
                <div class="p-4 text-sm text-neutral-600 dark:text-neutral-300">No upcoming registration windows in the next <?php echo e($windowDays); ?> days.</div>
            <?php else: ?>
                <ul class="divide-y divide-neutral-200 dark:divide-white/10">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $openingSoon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="px-4 py-3">
                            <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <div class="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                                        <?php echo e($lg->title); ?>

                                    </div>
                                    <div class="mt-0.5 text-xs text-neutral-600 dark:text-neutral-400">
                                        <?php echo e($lg->location ?: '—'); ?> • Starts <?php echo e($this->fmtYmd($lg->start_date)); ?> • <?php echo e($lg->length_weeks); ?> weeks
                                    </div>
                                    <div class="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                                        Opens <?php echo e($this->fmtYmd($lg->registration_start_date)); ?>

                                        <!--[if BLOCK]><![endif]--><?php if($lg->registration_end_date): ?> • Closes <?php echo e($this->fmtYmd($lg->registration_end_date)); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>

                                <div class="flex items-center gap-2">
                                    <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($this->publicInfoUrl($lg)).'','variant' => 'outline','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($this->publicInfoUrl($lg)).'','variant' => 'outline','size' => 'sm']); ?>
                                        View details
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                                    <!--[if BLOCK]><![endif]--><?php if(filled($lg->info?->registration_url)): ?>
                                        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['as' => 'a','href' => ''.e($lg->info->registration_url).'','target' => '_blank','rel' => 'noopener','variant' => 'secondary','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => ''.e($lg->info->registration_url).'','target' => '_blank','rel' => 'noopener','variant' => 'secondary','size' => 'sm']); ?>
                                            Pre-register
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH C:\Development\web_sites\archerdb\resources\views\livewire/landing/upcoming-events.blade.php ENDPATH**/ ?>