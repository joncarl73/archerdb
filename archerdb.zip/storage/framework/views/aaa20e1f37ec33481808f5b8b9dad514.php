<?php

use Livewire\Volt\Component;
use App\Models\TrainingSession;

?>

<section class="w-full">
    
    <div class="mx-auto max-w-7xl">
        <div class="sm:flex sm:items-center">
            <div class="sm:flex-auto">
                <h1 class="text-base font-semibold text-gray-900 dark:text-white">
                    Record scores
                </h1>
                <p class="mt-2 text-sm text-gray-700 dark:text-gray-300">
                    <?php echo e($session->title ?? 'Session'); ?> — <?php echo e($session->distance_m ? $session->distance_m . 'm' : '—'); ?> •
                    <?php echo e($session->arrows_per_end); ?> arrows/end •
                    up to <?php echo e($session->max_score); ?> points/arrow
                    <!--[if BLOCK]><![endif]--><?php if(($session->x_value ?? 10) > $session->max_score): ?>
                        (X=<?php echo e($session->x_value); ?>)
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </p>
            </div>
            <div class="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
                <a href="<?php echo e(route('training.index')); ?>" wire:navigate
                   class="block rounded-md px-3 py-2 text-center text-sm font-semibold inset-ring inset-ring-gray-300
                          hover:bg-gray-50 dark:inset-ring-white/10 dark:hover:bg-white/5">
                    Back to sessions
                </a>
            </div>
        </div>
    </div>

    
    <div class="mt-8">
        <div class="mx-auto max-w-7xl">
            <div class="overflow-hidden rounded-xl border border-gray-200 shadow-sm dark:border-zinc-700">
                <table class="w-full text-left">
                    <thead class="bg-white dark:bg-gray-900">
                    <tr>
                        <th class="py-3.5 pl-4 pr-3 text-sm font-semibold">End</th>
                        <th class="px-3 py-3.5 text-sm font-semibold">Arrows</th>
                        <th class="px-3 py-3.5 text-sm font-semibold w-24">End&nbsp;Total</th>
                        <th class="px-3 py-3.5 text-sm font-semibold w-20">X</th>
                    </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-white/10">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $session->ends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $end): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-4 pl-4 pr-3 text-sm font-medium">
                                <?php echo e($end->end_number); ?>

                            </td>

                            <td class="px-3 py-3">
                                <div class="grid gap-2"
                                     style="grid-template-columns: repeat(<?php echo e($arrowsPerEnd); ?>, minmax(0,1fr));">
                                    <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < $arrowsPerEnd; $i++): ?>
                                        <?php ($val = $end->scores[$i] ?? null); ?>
                                        <button
                                            wire:click="startEntry(<?php echo e($end->end_number); ?>, <?php echo e($i); ?>)"
                                            class="h-10 rounded-lg inset-ring inset-ring-gray-300 hover:bg-gray-50
                                                   dark:inset-ring-gray-700 dark:hover:bg-white/5 <?php if($selectedEnd === $end->end_number && $selectedArrow === $i): ?> ring-2 ring-indigo-500 <?php endif; ?>">
                                            <!--[if BLOCK]><![endif]--><?php if($val === null): ?>
                                                <span class="opacity-40">·</span>
                                            <?php elseif((int)$val === 0): ?>
                                                M
                                            <?php elseif($scoringSystem === '10' && (int)$val === (int)($session->x_value ?? 10)): ?>
                                                X
                                            <?php else: ?>
                                                <?php echo e($val); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </button>
                                    <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </td>

                            <td class="px-3 py-3 text-sm tabular-nums">
                                <?php echo e($end->end_score ?? 0); ?>

                            </td>
                            <td class="px-3 py-3 text-sm tabular-nums">
                                <?php echo e($end->x_count ?? 0); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>

                    
                    <tfoot class="bg-gray-50/60 dark:bg-white/5">
                        <?php ($completedEnds = 0); ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $session->ends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($hasAny = false); ?>
                            <!--[if BLOCK]><![endif]--><?php if(is_array($e->scores)): ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $e->scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--[if BLOCK]><![endif]--><?php if(!is_null($sv)): ?>
                                        <?php ($hasAny = true); ?>
                                        <?php break; ?>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($hasAny): ?>
                                <?php ($completedEnds++); ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php ($plannedEnds = $session->ends_planned ?? $session->ends->count()); ?>

                        <tr>
                            <th class="py-3.5 pl-4 pr-3 text-sm font-semibold text-gray-900 dark:text-white">Totals</th>
                            <td class="px-3 py-3 text-sm text-gray-600 dark:text-gray-300">
                                Ends completed: <?php echo e($completedEnds); ?> / <?php echo e($plannedEnds); ?>

                            </td>
                            <td class="px-3 py-3 text-sm font-semibold tabular-nums">
                                <?php echo e($session->total_score); ?>

                            </td>
                            <td class="px-3 py-3 text-sm font-semibold tabular-nums">
                                <?php echo e($session->x_count); ?>

                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($showKeypad): ?>
        <div class="fixed inset-0 z-40">
            
            <div class="absolute inset-0 bg-black/40" wire:click="closeKeypad"></div>

            
            <div
                class="absolute inset-y-0 right-0 w-full max-w-md h-full overflow-y-auto bg-white p-6 shadow-xl dark:bg-zinc-900"
                x-data
                x-transition:enter="transform transition ease-out duration-200"
                x-transition:enter-start="translate-x-full"
                x-transition:enter-end="translate-x-0"
                x-transition:leave="transform transition ease-in duration-150"
                x-transition:leave-start="translate-x-0"
                x-transition:leave-end="translate-x-full"
            >
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
                        End #<?php echo e($selectedEnd); ?>, Arrow <?php echo e($selectedArrow + 1); ?>

                    </h2>
                    <div class="flex items-center gap-3">
                        <label class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                            <span>Auto-advance ends</span>
                            <?php if (isset($component)) { $__componentOriginal588f41139f2abb21ceb2672b8ca8b135 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal588f41139f2abb21ceb2672b8ca8b135 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::switch','data' => ['wire:model.live' => 'autoAdvanceEnds']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'autoAdvanceEnds']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal588f41139f2abb21ceb2672b8ca8b135)): ?>
<?php $attributes = $__attributesOriginal588f41139f2abb21ceb2672b8ca8b135; ?>
<?php unset($__attributesOriginal588f41139f2abb21ceb2672b8ca8b135); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal588f41139f2abb21ceb2672b8ca8b135)): ?>
<?php $component = $__componentOriginal588f41139f2abb21ceb2672b8ca8b135; ?>
<?php unset($__componentOriginal588f41139f2abb21ceb2672b8ca8b135); ?>
<?php endif; ?>
                        </label>
                        <button class="rounded-md p-2 text-gray-500 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/10"
                                wire:click="closeKeypad">✕</button>
                    </div>
                </div>

                <div class="mt-6 space-y-6">
                    
                    <div>
                        <div class="grid grid-cols-6 gap-2">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->keypadKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button
                                    wire:click="keypad('<?php echo e($key); ?>')"
                                    class="h-12 rounded inset-ring inset-ring-gray-300 hover:bg-gray-50
                                           dark:inset-ring-gray-700 dark:hover:bg-white/5">
                                    <?php echo e($key); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mt-4 flex items-center gap-3">
                            <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'ghost','wire:click' => 'clearCurrent']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'ghost','wire:click' => 'clearCurrent']); ?>Clear <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['variant' => 'primary','wire:click' => 'done']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'primary','wire:click' => 'done']); ?>Done <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="rounded-xl border border-gray-200 p-4 dark:border-zinc-700">
                        <?php ($e = $session->ends->firstWhere('end_number', $selectedEnd)); ?>
                        <div class="text-sm text-gray-700 dark:text-gray-300">
                            <div class="mb-2 font-medium">Current end</div>
                            <div class="flex gap-2">
                                <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < $arrowsPerEnd; $i++): ?>
                                    <?php ($v = $e?->scores[$i] ?? null); ?>
                                    <span class="inline-flex h-9 w-9 items-center justify-center rounded-md inset-ring inset-ring-gray-200 dark:inset-ring-white/10 <?php if($selectedArrow === $i): ?> ring-2 ring-indigo-500 <?php endif; ?>">
                                        <!--[if BLOCK]><![endif]--><?php if($v === null): ?>
                                            <span class="opacity-40">·</span>
                                        <?php elseif((int)$v === 0): ?>
                                            M
                                        <?php elseif($scoringSystem === '10' && (int)$v === (int)($session->x_value ?? 10)): ?>
                                            X
                                        <?php else: ?>
                                            <?php echo e($v); ?>

                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </span>
                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="mt-3 text-xs text-gray-500 dark:text-gray-400">
                                End total: <?php echo e($e?->end_score ?? 0); ?> • X: <?php echo e($e?->x_count ?? 0); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</section><?php /**PATH C:\Development\web_sites\archerdb\resources\views\livewire/training/record.blade.php ENDPATH**/ ?>