

<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH C:\Development\web_sites\archerdb\vendor\livewire\flux\src/../stubs/resources/views/flux/modal/close.blade.php ENDPATH**/ ?>