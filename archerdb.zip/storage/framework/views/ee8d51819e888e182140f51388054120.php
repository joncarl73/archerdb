<?php $__env->startComponent('mail::message'); ?>
# New Contact Message

**From:** <?php echo new \Illuminate\Support\EncodedHtmlString($name); ?> (<?php echo new \Illuminate\Support\EncodedHtmlString($email); ?>)

**Message:**

<?php echo new \Illuminate\Support\EncodedHtmlString($messageBody); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Development\web_sites\archerdb\resources\views/emails/contact-message.blade.php ENDPATH**/ ?>