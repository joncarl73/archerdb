<?php

// database/migrations/2025_10_07_190002_backfill_event_kind_defaults.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // If linked to a league: mirror league type → event kind
        DB::statement("
      UPDATE events e
      JOIN leagues l ON l.id = e.league_id
      SET e.kind = CASE
          WHEN (l.type = 'open')  THEN 'league.open'
          WHEN (l.type = 'closed') THEN 'league.closed'
          ELSE 'single.day'
        END
      WHERE e.kind IS NULL OR e.kind = ''
    ");

        // Scoring defaults:
        // - remote/single: personal
        // - multi: either (kiosk or personal allowed)
        // - league.*: leave null so leagues control scoring with existing fields
        DB::table('events')
            ->whereIn('kind', ['remote.league', 'single.day'])
            ->whereNull('scoring_mode')
            ->update(['scoring_mode' => 'personal']);

        DB::table('events')
            ->where('kind', 'multi.day')
            ->whereNull('scoring_mode')
            ->update(['scoring_mode' => 'either']);
    }

    public function down(): void {}
};
